using Microsoft.EntityFrameworkCore;
using SopalTrace.Application.DTOs.QualityPlans.Referentiels;
using SopalTrace.Application.Interfaces;
using SopalTrace.Infrastructure.Data;

namespace SopalTrace.Infrastructure.Services;

public class ReferentielService : IReferentielService
{
    private readonly SopalTraceDbContext _context;

    public ReferentielService(SopalTraceDbContext context)
    {
        _context = context;
    }

    public async Task<ReferentielsResponseDto> GetFabricationReferentielsAsync()
    {
        var typesRobinet = (await _context.TypeRobinets
            .Where(x => x.Actif)
            .Select(x => new { x.Code, x.Libelle })
            .ToListAsync())
            .Select(x => new ReferenceItemDto(null, x.Code, x.Libelle, true, null))
            .ToList();

        var naturesComposant = (await _context.NatureComposants
            .Where(x => x.Actif)
            .Select(x => new { x.Code, x.Libelle, x.EstGenerique })
            .ToListAsync())
            .Select(x => new ReferenceItemDto(null, x.Code, x.Libelle, true, x.EstGenerique))
            .ToList();

        var operations = (await _context.Operations
            .Where(x => x.Actif)
            .Select(x => new { x.Code, x.Libelle })
            .ToListAsync())
            .Select(x => new ReferenceItemDto(null, x.Code, x.Libelle, true, null))
            .ToList();

        var typesControle = (await _context.TypeControles
            .Where(x => x.Actif)
            .Select(x => new { x.Id, x.Code, x.Libelle })
            .ToListAsync())
            .Select(x => new ReferenceItemDto(x.Id, x.Code, x.Libelle, true, null))
            .ToList();

        var typesCaracteristique = (await _context.TypeCaracteristiques
            .Where(x => x.Actif)
            .Select(x => new { x.Id, x.Code, x.Libelle })
            .ToListAsync())
            .Select(x => new ReferenceItemDto(x.Id, x.Code, x.Libelle, true, null))
            .ToList();

        var moyensControle = (await _context.MoyenControles
            .Where(x => x.Actif)
            .Select(x => new { x.Id, x.Code, x.Libelle })
            .ToListAsync())
            .Select(x => new ReferenceItemDto(x.Id, x.Code, x.Libelle, true, null))
            .ToList();

        var typesSections = (await _context.TypeSections
            .Where(x => x.Actif)
            .Select(x => new { x.Id, x.Code, x.Libelle })
            .ToListAsync())
            .Select(x => new ReferenceItemDto(x.Id, x.Code, x.Libelle, true, null))
            .ToList();

        return new ReferentielsResponseDto(
            TypesRobinet: typesRobinet,

            NaturesComposant: naturesComposant,

            Operations: operations,

            TypesControle: typesControle,

            TypesCaracteristique: typesCaracteristique,

            MoyensControle: moyensControle,

            Periodicites: await _context.Periodicites
                .Where(x => x.Actif)
                .OrderBy(x => x.OrdreAffichage)
                .Select(x => new PeriodiciteDto(
                    x.Id,
                    x.Code,
                    x.Libelle,
                    x.FrequenceNum,
                    x.FrequenceUnite,
                    x.OrdreAffichage,
                    true))
                .ToListAsync(),

            TypesSections: typesSections,

            Instruments: await _context.Instruments
                .Where(x => x.Actif)
                .Select(x => new InstrumentDto(x.CodeInstrument, x.Designation, true))
                .ToListAsync(),

            Gammes: await _context.NatureComposantOperations
                .Select(g => new GammeDto(g.NatureComposantCode, g.OperationCode))
                .ToListAsync()
        );
    }

    public async Task<ArticleDto?> GetArticleInfosAsync(string codeArticle)
    {
        var article = await _context.Itmmasters
            .Where(a => a.CodeArticle == codeArticle)
            .Select(a => new ArticleDto(
                a.CodeArticle,
                a.Designation,
                a.TypeRobinetCode,
                a.NatureComposantCode
            ))
            .FirstOrDefaultAsync();

        return article;
    }
}