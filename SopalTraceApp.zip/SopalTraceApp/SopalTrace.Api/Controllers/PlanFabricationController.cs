﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SopalTrace.Application.DTOs.QualityPlans.PlanFabrication;
using SopalTrace.Application.DTOs.QualityPlans.Referentiels;
using SopalTrace.Application.Interfaces;
using SopalTrace.Domain.Entities;
using SopalTrace.Infrastructure.Data;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SopalTrace.Api.Controllers;

[Route("api/plans-fabrication")]
[ApiController]
public class PlanFabricationController : ControllerBase
{
    private readonly IPlanFabricationService _planService;
    // Garder le _context uniquement si vous laissez la méthode "CreerNouvellePeriodicite" ici pour le moment.
    private readonly SopalTraceDbContext _context;

    public PlanFabricationController(IPlanFabricationService planService, SopalTraceDbContext context)
    {
        _planService = planService;
        _context = context;
    }

    [HttpPost("instancier")]
    public async Task<IActionResult> InstancierPlan([FromBody] CreatePlanRequestDto request)
    {
        var id = await _planService.InstancierPlanDepuisModeleAsync(request);
        return Ok(new { success = true, planId = id, message = "Plan instancié en BROUILLON." });
    }

    [HttpGet("verifier-brouillon")]
    public async Task<IActionResult> VerifierBrouillon([FromQuery] string articleCode, [FromQuery] Guid modeleId)
    {
        var id = await _context.PlanFabEntetes
            .Where(p => p.CodeArticleSage == articleCode && p.ModeleSourceId == modeleId && p.Statut == "BROUILLON")
            .Select(p => p.Id)
            .FirstOrDefaultAsync();

        if (id != Guid.Empty) return Ok(new { success = true, exists = true, planId = id });
        return Ok(new { success = true, exists = false });
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetPlan(Guid id)
    {
        var data = await _planService.GetPlanByIdAsync(id);
        return Ok(new { success = true, data });
    }

    [HttpPut("{id}/valeurs")]
    public async Task<IActionResult> MettreAJourValeurs(Guid id, [FromBody] List<SectionEditDto> request, [FromQuery] string? legendeMoyens = null, [FromQuery] bool finaliser = true)
    {
        var success = await _planService.MettreAJourValeursPlanAsync(id, request, legendeMoyens, finaliser);
        if (!success) return NotFound(new { success = false, message = "Plan introuvable." });

        var msg = finaliser ? "Plan mis à jour avec succès et rendu ACTIF." : "Plan mis à jour en tant que brouillon.";
        return Ok(new { success = true, message = msg });
    }

    [HttpPost("clone")]
    public async Task<IActionResult> ClonerPlan([FromBody] ClonePlanRequestDto request)
    {
        var id = await _planService.ClonerPlanPourNouvelArticleAsync(request);
        return Ok(new { success = true, planId = id, message = "Plan cloné avec succès." });
    }

    [HttpPost("nouvelle-version")]
    public async Task<IActionResult> CreerVersion([FromBody] NouvelleVersionRequestDto request)
    {
        var id = await _planService.CreerNouvelleVersionPlanAsync(request);
        return Ok(new { success = true, planId = id, message = "V2 générée avec succès." });
    }

    [HttpPost("restaurer")]
    public async Task<IActionResult> RestaurerPlan([FromBody] RestaurerPlanRequestDto request)
    {
        try
        {
            var id = await _planService.RestaurerPlanArchiveAsync(request);
            return Ok(new { success = true, planId = id, message = "Plan de fabrication restauré et activé avec succès." });
        }
        catch (Exception ex)
        {
            return BadRequest(new { success = false, message = ex.Message });
        }
    }

    [HttpPost("periodicites")]
    public async Task<IActionResult> CreerNouvellePeriodicite([FromBody] CreatePeriodiciteDto request)
    {
        var existeDeja = await _context.Periodicites.AnyAsync(x => x.Code == request.Code);
        if (existeDeja) return BadRequest(new { success = false, message = "Une périodicité avec ce code existe déjà." });

        var periodicite = new Periodicite
        {
            Id = Guid.NewGuid(), Code = request.Code, Libelle = request.Libelle,
            FrequenceNum = request.FrequenceNum, FrequenceUnite = request.FrequenceUnite,
            OrdreAffichage = request.OrdreAffichage, Actif = request.Actif
        };

        _context.Periodicites.Add(periodicite);
        await _context.SaveChangesAsync();

        return Ok(new { success = true, periodiciteId = periodicite.Id });
    }
}