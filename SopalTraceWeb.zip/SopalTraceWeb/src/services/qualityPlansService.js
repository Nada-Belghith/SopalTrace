import apiClient from './apiClient';

export const qualityPlansService = {
  // Dictionnaires pour fabrication
  getDictionnaires() {
    return apiClient.get('/referentiels/fabrication');
  },

  // --- Modèles de fabrication ---
  createModele(payload) {
    return apiClient.post('/modeles-fabrication', payload);
  },

  getModeleById(id) {
    return apiClient.get(`/modeles-fabrication/${id}`);
  },

  newModeleVersion(payload) {
    return apiClient.post('/modeles-fabrication/nouvelle-version', payload);
  },

  restoreModele(payload) {
    return apiClient.post('/modeles-fabrication/restaurer', payload);
  },

  // --- Périodicités liés aux plans ---
  createPeriodicite(payload) {
    return apiClient.post('/plans-fabrication/periodicites', payload);
  },

  // --- Sections des plans (scoped by planId) ---
  ajouterSections(planId, payload) {
    return apiClient.post(`/plans-fabrication/${planId}/sections`, payload);
  },

  updateSections(planId, payload) {
    return apiClient.put(`/plans-fabrication/${planId}/sections`, payload);
  },

  // --- Plans de fabrication ---
  instantiatePlan(payload) {
    return apiClient.post('/plans-fabrication/instancier', payload);
  },

  checkBrouillon(articleCode, modeleId) {
    return apiClient.get('/plans-fabrication/verifier-brouillon', {
      params: { articleCode, modeleId }
    });
  },

  annulerBrouillonPlan(planId) {
    return apiClient.delete(`/hub/plans/FAB/${planId}`);
  },

  clonePlan(payload) {
    return apiClient.post('/plans-fabrication/clone', payload);
  },

  getPlanById(id) {
    return apiClient.get(`/plans-fabrication/${id}`);
  },

  newPlanVersion(payload) {
    return apiClient.post('/plans-fabrication/nouvelle-version', payload);
  },

  // Mise à jour des valeurs du plan. 'finaliser' indique si on doit rendre le plan ACTIF
  updatePlanValues(id, payload, legendeMoyens = null, finaliser = true) {
    return apiClient.put(`/plans-fabrication/${id}/valeurs`, payload, {
      params: { legendeMoyens, finaliser }
    });
  },

  // NOUVEAU : suppression d'un plan (utilisé pour annuler un brouillon créé cette session)
  deletePlan(planId) {
    return apiClient.delete(`/plans-fabrication/${planId}`);
  },

  // Restaurer un plan archivé
  restorePlan(payload) {
    return apiClient.post('/plans-fabrication/restaurer', payload);
  },

  getArticleFromERP(codeArticle) {
    return apiClient.get(`/referentiels/article/${codeArticle}`);
  },

  getModelesByFilters(typeRobinetCode, natureComposantCode, operationCode) {
    const params = new URLSearchParams();
    if (typeRobinetCode) params.append('typeRobinet', typeRobinetCode);
    if (natureComposantCode) params.append('natureComposant', natureComposantCode);
    if (operationCode) params.append('operation', operationCode); // Ajout décisif
    
    return apiClient.get(`/modeles-fabrication/liste?${params.toString()}`);
  },

  getPlansByFilters(typeRobinetCode, natureComposantCode, operationCode) {
    const params = new URLSearchParams();
    if (typeRobinetCode) params.append('typeRobinet', typeRobinetCode);
    if (natureComposantCode) params.append('natureComposant', natureComposantCode);
    if (operationCode) params.append('operation', operationCode);
    
    return apiClient.get(`/plans-fabrication/liste?${params.toString()}`);
  }
};
