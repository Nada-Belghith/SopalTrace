<template>
  <tr class="hover:bg-blue-50/20 transition-colors group">
    <!-- Catégorie (Caractéristique contrôlée) -->
    <td class="p-2 border-r border-slate-200 align-top w-[22%]">
      <select v-model="ligne.typeCaracteristiqueId" class="w-full bg-white border border-slate-200 rounded px-2 py-1.5 text-[11px] text-slate-700 outline-none focus:border-blue-500 cursor-pointer font-medium">
        <option :value="null" disabled>-- Caractéristique * --</option>
        <option v-for="tc in (store.typesCaracteristique || [])" :key="tc.id" :value="tc.id">{{ tc.libelle }}</option>
      </select>
    </td>

    <!-- Valeur (Éditable - Fond bleu) -->
    <td class="p-2 border-r border-slate-200 bg-blue-50/40 align-top text-center w-[12%]">
      <input v-model="ligne.valeurNominale" type="text" placeholder="Ex: Ø13"
             :disabled="isVisuel"
             :class="isVisuel ? 'opacity-50 cursor-not-allowed bg-slate-100' : 'bg-white'"
             class="w-full text-center font-semibold text-slate-700 border border-slate-300 rounded px-2 py-1 outline-none focus:border-blue-500 text-sm transition-opacity">
    </td>

    <!-- Limite Spécif. (Min / Max) -->
    <td class="p-2 border-r border-slate-200 align-top text-center w-[14%] min-w-[170px]">
      <div class="grid grid-cols-2 gap-2">
        <input
          v-model.number="ligne.toleranceInferieure"
          @input="updateLimiteSpecTexte"
          type="number"
          step="any"
          placeholder="Min"
          :disabled="isVisuel"
          :class="isVisuel ? 'opacity-50 cursor-not-allowed bg-slate-100' : 'bg-white'"
          class="w-full text-center font-semibold text-slate-700 border border-slate-300 rounded px-2 py-1.5 outline-none focus:border-slate-500 text-sm transition-opacity"
        >
        <input
          v-model.number="ligne.toleranceSuperieure"
          @input="updateLimiteSpecTexte"
          type="number"
          step="any"
          placeholder="Max"
          :disabled="isVisuel"
          :class="isVisuel ? 'opacity-50 cursor-not-allowed bg-slate-100' : 'bg-white'"
          class="w-full text-center font-semibold text-slate-700 border border-slate-300 rounded px-2 py-1.5 outline-none focus:border-slate-500 text-sm transition-opacity"
        >
      </div>
    </td>

    <!-- Type de contrôle (Éditable) -->
    <td class="p-2 border-r border-slate-200 align-top w-[12%]">
      <select v-model="ligne.typeControleId" class="w-full bg-white border border-slate-200 rounded px-2 py-1.5 text-[11px] text-slate-700 outline-none focus:border-blue-500 cursor-pointer">
        <option :value="null" disabled>-- Type * --</option>
        <option v-for="tco in (store.typesControle || [])" :key="tco.id" :value="tco.id">{{ tco.code }}</option>
      </select>
    </td>

    <!-- Moyen de contrôle (Éditable) -->
    <td class="p-2 border-r border-slate-200 align-top w-[12%]">
      <select v-model="ligne.moyenControleId" class="w-full bg-white border border-slate-200 rounded px-2 py-1.5 text-[11px] text-slate-700 outline-none focus:border-blue-500 cursor-pointer">
        <option :value="null">-- Moyen --</option>
        <option v-for="mco in (store.moyensControle || [])" :key="mco.id" :value="mco.id">{{ mco.libelle }}</option>
      </select>
    </td>

    <!-- Code instrument (Éditable - Combobox) -->
    <td class="p-2 border-r border-slate-200 align-top w-[12%]">
      <div class="flex gap-1 items-center">
        <select @change="(e) => { if (e.target.value) ligne.instrumentCode = e.target.value; e.target.value = ''; }" 
                :disabled="isVisuel"
                :class="isVisuel ? 'opacity-50 cursor-not-allowed bg-slate-100' : 'bg-white cursor-pointer'"
                class="flex-1 border border-slate-200 rounded px-2 py-1.5 text-[11px] text-slate-700 outline-none focus:border-blue-500 transition-opacity">
          <option value="">-- Outil --</option>
          <option v-for="ins in (store.instruments || [])" :key="ins.codeInstrument" :value="ins.codeInstrument">
            {{ ins.codeInstrument }}
          </option>
        </select>
        <input v-model="ligne.instrumentCode" type="text" placeholder="Perso"
               :disabled="isVisuel"
               :class="isVisuel ? 'opacity-50 cursor-not-allowed bg-slate-100' : 'bg-white'"
               class="flex-1 border border-slate-200 rounded px-2 py-1.5 text-[10px] text-slate-700 outline-none focus:border-blue-500 transition-opacity">
      </div>
    </td>

    <!-- Observations (Éditable) -->
    <td class="p-2 border-r border-slate-200 align-top w-[18%] min-w-[180px]">
      <input v-model="ligne.observations" type="text" placeholder="Infos (Optionnel)..." 
             class="w-full bg-white border border-slate-200 rounded px-2 py-1.5 text-xs text-slate-600 outline-none focus:border-blue-500">
    </td>

    <!-- Actions (Masqué par défaut, apparaît au survol) -->
    <td class="p-2 align-middle text-center opacity-0 group-hover:opacity-100 transition-opacity w-8">
      <button @click="$emit('remove', ligne.id)" class="text-slate-300 hover:text-red-500 transition-colors p-2 rounded-lg hover:bg-red-50" title="Supprimer cette ligne">
        <i class="pi pi-trash"></i>
      </button>
    </td>
  </tr>
</template>

<script setup>
import { computed, watch } from 'vue';
import { useFabModeleStore } from '@/stores/fabModeleStore';

const props = defineProps({
  ligne: { type: Object, required: true },
  section: { type: Object, required: true }
});

defineEmits(['remove']);

const store = useFabModeleStore();

const isVisuel = computed(() => {
  const typeCtrl = (store.typesControle || []).find(t => t.id === props.ligne.typeControleId);
  return typeCtrl?.code === 'VISUEL';
});

watch(isVisuel, (devenuVisuel) => {
  if (devenuVisuel) {
    props.ligne.groupeInstrumentId = null;
    props.ligne.instrumentCode = null;
    props.ligne.valeurNominale = null;
    props.ligne.toleranceInferieure = null;
    props.ligne.toleranceSuperieure = null;
    props.ligne.limiteSpecTexte = '';
  }
});

const updateLimiteSpecTexte = () => {
  const min = props.ligne.toleranceInferieure;
  const max = props.ligne.toleranceSuperieure;

  if (min === null || min === undefined || min === '' || max === null || max === undefined || max === '') {
    props.ligne.limiteSpecTexte = '';
    return;
  }

  props.ligne.limiteSpecTexte = `${min} / ${max}`;
};
</script>
