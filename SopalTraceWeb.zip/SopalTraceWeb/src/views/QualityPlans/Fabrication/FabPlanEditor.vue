<template>
  <div class="bg-slate-50 min-h-screen p-4 md:p-8 font-sans text-slate-800">
    <Toast position="top-right" />

    <VersioningDialog :visible="showVersioningDialog"
                      :mode="versioningMode"
                      :is-loading="isSaving"
                      @confirm="onVersioningConfirm"
                      @cancel="showVersioningDialog = false"
                      @update:visible="showVersioningDialog = $event" />

    <div class="max-w-[1600px] mx-auto">
      <div class="animate-in fade-in zoom-in-95 duration-500">

        <div class="flex flex-col md:flex-row justify-between items-start mb-8 gap-4">
          <div class="flex-1 min-w-0">
            <h1 class="text-3xl font-black text-slate-900 tracking-tight truncate">
              {{ headerTitle }}
            </h1>
            <p class="text-sm text-slate-500 mt-1 font-medium">{{ headerSubtitle }}</p>

            <div v-if="isEditMode" class="mt-4 flex flex-wrap items-center gap-3">
              <div class="inline-flex items-center gap-3 bg-blue-50/50 border border-blue-100 text-blue-800 px-4 py-2 rounded-xl shadow-sm max-w-full">
                <i class="pi pi-box text-blue-500 shrink-0"></i>
                <span class="font-mono font-bold truncate shrink-0">{{ codeAffiche }}</span>
                <span class="text-blue-300 shrink-0">|</span>
                <span class="font-semibold text-sm truncate">{{ plan?.designation || wizard.designationArticle }}</span>
              </div>

              <div class="inline-flex items-center gap-2 bg-slate-100 border border-slate-200 text-slate-700 px-4 py-2 rounded-xl shadow-sm shrink-0">
                <i class="pi pi-cog text-slate-400"></i>
                <span class="text-xs font-bold uppercase tracking-widest">Opération :</span>
                <span class="font-black">{{ plan?.operationCode || 'NON DÉFINIE' }}</span>
              </div>
            </div>
          </div>

          <div class="flex items-center gap-3 shrink-0">
            <div v-if="isEditMode" class="flex items-center gap-2 bg-white p-2 rounded-xl shadow-sm border border-slate-200">
              <span v-if="plan?.statut === 'BROUILLON'" class="px-4 py-1.5 bg-amber-50 text-amber-700 font-black text-[10px] uppercase rounded-lg border border-amber-200 tracking-widest"><i class="pi pi-pencil mr-1"></i> Brouillon</span>
              <span v-else-if="plan?.statut === 'ACTIF'" class="px-4 py-1.5 bg-emerald-50 text-emerald-700 font-black text-[10px] uppercase rounded-lg border border-emerald-200 tracking-widest"><i class="pi pi-check-circle mr-1"></i> Actif (Prod)</span>
              <span v-else-if="plan?.statut === 'ARCHIVE'" class="px-4 py-1.5 bg-red-50 text-red-700 font-black text-[10px] uppercase rounded-lg border border-red-200 tracking-widest"><i class="pi pi-box mr-1"></i> Archivé</span>

              <div class="px-4 py-1.5 bg-slate-100 text-slate-600 font-black text-[10px] uppercase rounded-lg border border-slate-200 tracking-widest">
                VERSION {{ plan?.version || 1 }}
              </div>
            </div>

            <button v-if="isEditMode" @click="onCloseEditor" class="text-slate-400 hover:text-red-500 transition-colors ml-2 bg-white border border-slate-200 p-2.5 rounded-xl shadow-sm hover:border-red-200 hover:bg-red-50">
              <i class="pi pi-times"></i>
            </button>
          </div>
        </div>

        <PlanWizardStep v-if="!isEditMode"
                        :wizard="wizard"
                        @load-model="onWizardGenerate" />

        <div v-else class="bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden">
          <div class="bg-[#1e293b] text-white px-5 py-4 flex justify-between items-center">
            <div class="flex items-center gap-3 font-bold tracking-wide text-sm">
              <i class="pi pi-sliders-v text-blue-400"></i> Éditeur de Structure du Plan
            </div>
          </div>

          <div v-if="isLoadingData" class="py-20 text-center text-blue-500">
            <i class="pi pi-spin pi-spinner text-4xl mb-4"></i>
            <p class="text-xs font-black uppercase tracking-widest">Chargement de l'arbre...</p>
          </div>

          <div v-else class="p-6 md:p-8">
            <div class="mb-4">
              <h3 class="text-[11px] font-black text-slate-500 uppercase tracking-widest">Structure des lignes de contrôle</h3>
            </div>

            <template v-if="sections.length === 0">
              <div class="p-8 text-center text-slate-400 text-sm italic bg-slate-50 rounded-lg border border-slate-200 mb-6">
                Cliquez sur "Créer une nouvelle section" pour commencer.
              </div>
            </template>

            <FabPlanSectionCard v-for="(section, index) in sections"
                                :key="section.id"
                                :section="section"
                                :index="index"
                                :periodicites="store.periodicites"
                                @add-ligne="ajouterLigneASection(index)"
                                @remove="supprimerSection(section.id)"
                                @remove-ligne="(ligneId) => supprimerLigneASection(index, ligneId)"
                                @update:section="(updatedSection) => mettreAJourSection(index, updatedSection)" />

            <div class="mt-2">
              <button @click="ajouterSection" class="w-full p-4 bg-slate-50 text-center border border-dashed border-slate-300 hover:border-blue-400 rounded-lg hover:bg-blue-50 transition-colors text-slate-500 hover:text-blue-600 text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2">
                <i class="pi pi-plus-circle text-lg"></i> Créer une nouvelle section
              </button>
            </div>

            <div v-if="hasCustomInstrumentsGlobal"
                 :class="[
                'mt-6 px-4 py-3 rounded-lg',
                showLegendValidation && !legendeMoyens
                  ? 'bg-yellow-50 border-2 border-yellow-300'
                  : 'bg-slate-50 border border-slate-200'
              ]">
              <div class="flex items-start gap-2 mb-2">
                <i :class="[
                    'pi text-base mt-0.5',
                    showLegendValidation && !legendeMoyens
                      ? 'pi-exclamation-circle text-yellow-600'
                      : 'pi-info-circle text-slate-500'
                  ]"></i>
                <div>
                  <label :class="[
                      'block text-[10px] font-black uppercase tracking-widest',
                      showLegendValidation && !legendeMoyens ? 'text-yellow-800' : 'text-slate-700'
                    ]">
                    {{ showLegendValidation && !legendeMoyens ? '⚠️ Légende OBLIGATOIRE' : 'Légende des moyens' }}
                  </label>
                  <p :class="[
                      'text-[9px] mt-0.5',
                      showLegendValidation && !legendeMoyens ? 'text-yellow-700' : 'text-slate-500'
                    ]">
                    Texte personnalisé utilisé - veuillez documenter les abréviations
                  </p>
                </div>
              </div>
              <textarea v-model="legendeMoyens"
                        placeholder="Ex: PAC*=PAC512,PAC612"
                        rows="2"
                        :class="[
                  'w-full border rounded px-3 py-2 text-xs text-slate-700 outline-none shadow-sm',
                  showLegendValidation && !legendeMoyens
                    ? 'bg-red-50 border-red-300 focus:border-red-500'
                    : 'bg-white border-slate-300 focus:border-blue-500'
                ]"></textarea>
              <p v-if="showLegendValidation && !legendeMoyens" class="text-[9px] text-red-600 font-bold mt-1">❌ Remplissez la légende avant d'enregistrer!</p>
            </div>
          </div>

          <div class="bg-slate-50 border-t border-slate-200 p-6 flex justify-end">
            <EditorActions :label="editorLabel"
                           loading-label="Traitement..."
                           :icon="editorIcon"
                           :variant="editorVariant"
                           :is-loading="isSaving"
                           @submit="onEditorSubmit"
                           @cancel="onEditorCancel" />
          </div>
        </div>

      </div>
    </div>
  </div>
</template>

<script setup>
  import { ref, onMounted, watch, computed, onUnmounted } from 'vue';
  import { useRoute, useRouter, onBeforeRouteLeave } from 'vue-router';
  import { useToast } from 'primevue/usetoast';
  import Toast from 'primevue/toast';

  import { qualityPlansService } from '@/services/qualityPlansService';
  import { usePlanVersioning } from '@/composables/useVersioning';
  import { usePlanWizard } from '@/composables/usePlanWizard';
  import { useFabModeleStore } from '@/stores/fabModeleStore';
  import { prepareModeleDataAndFrequencies } from '@/utils/modelMapper';

  import VersioningDialog from '@/components/Shared/VersioningDialog.vue';
  import PlanWizardStep from '@/components/QualityPlans/PlanWizardStep.vue';
  import FabPlanSectionCard from '@/components/Fabrication/FabPlanSectionCard.vue';
  import EditorActions from '@/components/Shared/EditorActions.vue';

  const route = useRoute();
  const router = useRouter();
  const toast = useToast();
  const store = useFabModeleStore();
  const { creerNouvelleVersionPlan, mettreAJourValeurs, restaurerPlan } = usePlanVersioning();

  const wizard = usePlanWizard();
  const isGeneratingPlan = ref(false);

  const isFromWizard = ref(false);
  const planId = ref(route.params.id === 'nouveau' ? null : route.params.id);
  const plan = ref(null);
  const sections = ref([]);
  const legendeMoyens = ref('');
  const showLegendValidation = ref(false);
  const isLoadingData = ref(false);
  const isSaving = ref(false);

  // NOUVEAU : traqueur de session pour savoir si un brouillon a été créé en base pendant cette session
  const aEteCreePendantCetteSession = ref(false);

  const hasCustomInstrumentsGlobal = computed(() =>
    sections.value.some(section =>
      (section.lignes || []).some(ligne => /[\*~!@#$%^&]/.test(ligne.instrumentCode || ''))
    )
  );

  const isEditMode = computed(() => !!planId.value);
  const isArchived = computed(() => plan.value?.statut === 'ARCHIVE');

  const headerTitle = computed(() => {
    if (isFromWizard.value) return "Création d'un plan de Fabrication";
    if (plan.value && plan.value.statut === 'BROUILLON' && (plan.value.version || 0) <= 1) {
      return "Création d'un plan de Fabrication";
    }
    if (!isEditMode.value) return "Création d'un plan de Fabrication";
    if (isArchived.value) return "Restauration d'Archive";
    return 'Édition du Plan de Fabrication';
  });

  const headerSubtitle = computed(() => {
    if (isFromWizard.value) return "Configurez la structure du plan de fabrication.";
    if (plan.value && plan.value.statut === 'BROUILLON' && (plan.value.version || 0) <= 1) {
      return "Configurez la structure du plan de fabrication.";
    }
    if (!isEditMode.value) return "Configurez la structure du plan de fabrication.";
    if (isArchived.value) return "Vous consultez une archive. Restaurer réactivera cette version en production.";
    return "Modifiez la structure. L'ancienne version sera archivée automatiquement.";
  });

  const codeAffiche = computed(() => plan.value?.codeArticleSage || wizard.codeArticleSage || '');

  const editorLabel = computed(() => {
    if (!isEditMode.value) return 'Générer le Plan';
    if (isArchived.value) return 'Restaurer ce Plan';
    if (plan.value?.statut === 'BROUILLON' && (plan.value?.version || 0) <= 1) return 'Enregistrer & Activer le Plan';
    if (plan.value?.statut === 'ACTIF') return 'Créer une Nouvelle Version';
    return 'Enregistrer & Activer le Plan';
  });

  const editorIcon = computed(() => {
    if (!isEditMode.value) return 'pi pi-check';
    if (isArchived.value) return 'pi pi-history';
    if (plan.value?.statut === 'BROUILLON' && (plan.value?.version || 0) <= 1) return 'pi pi-save';
    return plan.value?.statut === 'ACTIF' ? 'pi pi-history' : 'pi pi-save';
  });

  const editorVariant = computed(() => {
    if (!isEditMode.value) return 'success';
    if (isArchived.value) return 'warning';
    if (plan.value?.statut === 'BROUILLON' && (plan.value?.version || 0) <= 1) return 'success';
    if (plan.value?.statut === 'ACTIF') return 'warning';
    return 'success';
  });

  const isExitingEditor = ref(false);
  const isCanceling = ref(false);
  let autoSaveInterval = null;
  const planCreationPayload = ref(null);


  const onCloseEditor = async () => {
    await sauvegarderBrouillonSilencieux();

    isExitingEditor.value = true;
    router.push('/dev/hub-plans');
  };

  // MODIFIÉ : onEditorCancel supprime le brouillon créé pendant la session, si nécessaire
  const onEditorCancel = async () => {
    isCanceling.value = true; // On bloque l'auto-save pour qu'il ne recrée rien
    isExitingEditor.value = true;

    try {
      // Si on a créé un brouillon en base de données pendant cette session, on le détruit !
      if (aEteCreePendantCetteSession.value && planId.value && planId.value !== 'nouveau') {
        await qualityPlansService.deletePlan(planId.value);
        toast.add({ severity: 'info', summary: 'Brouillon supprimé', detail: 'La création a été annulée et la base nettoyée.', life: 4000 });
      }
    } catch (error) {
      console.error("Erreur lors de la suppression du brouillon abandonné", error);
    } finally {
      router.push('/dev/hub-plans');
    }
  };

  onBeforeRouteLeave(async (_to, _from, next) => {
    if (isCanceling.value || isExitingEditor.value) {
      next();
      return;
    }

    await sauvegarderBrouillonSilencieux();
    next();
  });

  const showVersioningDialog = ref(false);
  const versioningMode = ref('new-version');

  onMounted(async () => {
    if (!store.isDicosLoaded) await store.fetchDictionnaires();
    if (planId.value && planId.value !== 'nouveau') await chargerPlan(planId.value);

    autoSaveInterval = setInterval(() => {
      if (plan.value?.statut === 'BROUILLON' || planCreationPayload.value) {
        sauvegarderBrouillonSilencieux();
      }
    }, 60000);
  });

  onUnmounted(() => {
    if (autoSaveInterval) {
      clearInterval(autoSaveInterval);
    }
  });

  watch(legendeMoyens, (value) => {
    if (value?.trim()) showLegendValidation.value = false;
  });

  const onWizardGenerate = async (payload) => {
    if (isGeneratingPlan.value) return;
    isGeneratingPlan.value = true;
    try {
      if (wizard.sourceType.value === 'MODELE') {
        const modeleId = wizard.selectedSourceId.value;
        const codeArticle = wizard.codeArticleSage.value;

        const resVal = await qualityPlansService.checkBrouillon(codeArticle, modeleId);
        if (resVal.data.exists) {
          toast.add({ severity: 'info', summary: 'Reprise', detail: 'Un brouillon existe déjà. Reprise en cours...', life: 4000 });
          planId.value = resVal.data.planId;
          isFromWizard.value = true;
          router.replace(`/dev/fab/plans/editer/${resVal.data.planId}`);
          await chargerPlan(resVal.data.planId);
        } else {
          const modRes = await qualityPlansService.getModeleById(modeleId);
          const data = modRes.data.data;
          plan.value = {
            statut: 'BROUILLON',
            codeArticleSage: codeArticle,
            designation: wizard.designationArticle.value,
            version: 1,
            operationCode: data.operationCode
          };
          planCreationPayload.value = {
            modeleSourceId: modeleId,
            codeArticleSage: codeArticle,
            designation: wizard.designationArticle.value,
            nom: '',
            creePar: 'ADMIN_QUALITE'
          };
          sections.value = mapModeleDataToSections(data);
          isFromWizard.value = true;
          planId.value = "nouveau";
        }
      } else {
        const res = await wizard.genererPlan();
        const newPlanId = res.data.planId;
        toast.add({ severity: 'success', summary: 'Succès', detail: 'Plan cloné.', life: 3000 });
        planId.value = newPlanId;
        router.replace(`/dev/fab/plans/editer/${newPlanId}`);
        await chargerPlan(newPlanId);
      }
    } catch (error) {
      console.error('Erreur génération:', error);
    } finally {
      isGeneratingPlan.value = false;
    }
  };

  const mapModeleDataToSections = (modeleModel) => {
    return (modeleModel.sections || []).map(sec => {
      let modeFreq = 'SANS';
      let periodiciteId = null;
      if (sec.frequenceLibelle) {
        const perMatch = store.periodicites.find(p => p.libelle === sec.frequenceLibelle);
        if (perMatch) {
          modeFreq = 'FIXE';
          periodiciteId = perMatch.id;
        } else {
          modeFreq = 'VARIABLE';
        }
      }

      // ⚠️ CORRECTION : Recherche exacte ou incluse (la plus longue)
      let typeSectionId = sec.typeSectionId || '';
      if (!typeSectionId && sec.libelleSection) {
        const secLib = sec.libelleSection.trim().toLowerCase();
        let bestMatch = null;
        let maxLength = -1;

        store.typesSection.forEach(t => {
          const tLib = (t.libelle || '').trim().toLowerCase();
          if (!tLib || secLib === 'section sans nom') return;

          if (secLib.includes(tLib)) {
            if (tLib.length > maxLength) {
              maxLength = tLib.length;
              bestMatch = t;
            }
          }
        });

        if (bestMatch) {
          typeSectionId = bestMatch.id;
        }
      }

      return {
        id: crypto.randomUUID(),
        isFromDb: false,
        modeleSectionId: sec.id,
        typeSectionId,
        modeFreq,
        periodiciteId,
        freqNum: 1,
        typeVariable: 'HEURE',
        freqHours: 1,
        isNewFreq: false,
        nom: sec.libelleSection,
        lignes: (sec.lignes || []).map(lig => ({
          id: crypto.randomUUID(),
          isFromDb: false,
          modeleLigneSourceId: lig.id,
          typeCaracteristiqueId: lig.typeCaracteristiqueId,
          typeControleId: lig.typeControleId,
          moyenControleId: lig.moyenControleId,
          instrumentCode: lig.instrumentCode,
          moyenTexteLibre: lig.moyenTexteLibre || '',
          valeurNominale: lig.valeurNominale ?? null,
          toleranceSuperieure: lig.toleranceSuperieure ?? null,
          toleranceInferieure: lig.toleranceInferieure ?? null,
          unite: lig.unite || '',
          limiteSpecTexte: lig.limiteSpecTexte || '',
          instruction: lig.instruction || '',
          observations: lig.observations || '',
          estCritique: lig.estCritique
        }))
      };
    });
  };

  // --- NOUVEAU CHARGEMENT : tri stable par ordreAffiche côté client ---
  const chargerPlan = async (id) => {
    isLoadingData.value = true;
    try {
      const res = await qualityPlansService.getPlanById(id);
      const data = res.data.data;
      plan.value = data;
      legendeMoyens.value = data.legendeMoyens || '';

      // ⚠️ 1. On force le tri des sections de 1 à X
      const sectionsTriees = [...(data.sections || [])].sort((a, b) =>
        (a.ordreAffiche || 0) - (b.ordreAffiche || 0)
      );

      sections.value = sectionsTriees.map(sec => {

        let modeFreq = 'SANS';
        let periodiciteId = null;
        if (sec.frequenceLibelle) {
          const perMatch = store.periodicites.find(p => p.libelle === sec.frequenceLibelle);
          if (perMatch) {
            modeFreq = 'FIXE';
            periodiciteId = perMatch.id;
          } else {
            modeFreq = 'VARIABLE';
          }
        }

        // ⚠️ CORRECTION : Recherche exacte ou incluse (la plus longue)
        let typeSectionId = sec.typeSectionId || '';
        if (!typeSectionId && sec.libelleSection) {
          const secLib = sec.libelleSection.trim().toLowerCase();
          let bestMatch = null;
          let maxLength = -1;

          store.typesSection.forEach(t => {
            const tLib = (t.libelle || '').trim().toLowerCase();
            if (!tLib || secLib === 'section sans nom') return;

            if (secLib.includes(tLib)) {
              if (tLib.length > maxLength) {
                maxLength = tLib.length;
                bestMatch = t;
              }
            }
          });

          if (bestMatch) {
            typeSectionId = bestMatch.id;
          }
        }

        // ⚠️ 3. On force le tri des lignes à l'intérieur de la section
        const lignesTriees = [...(sec.lignes || [])].sort((a, b) =>
          (a.ordreAffiche || 0) - (b.ordreAffiche || 0)
        );

        return {
          id: sec.id,
          isFromDb: true,
          typeSectionId,
          modeFreq,
          periodiciteId,
          freqNum: 1,
          typeVariable: 'HEURE',
          freqHours: 1,
          isNewFreq: false,
          nom: sec.libelleSection,
          lignes: lignesTriees.map(lig => ({
            id: lig.id,
            isFromDb: true,
            typeCaracteristiqueId: lig.typeCaracteristiqueId,
            typeControleId: lig.typeControleId,
            moyenControleId: lig.moyenControleId,
            instrumentCode: lig.instrumentCode,
            moyenTexteLibre: lig.moyenTexteLibre || '',
            valeurNominale: lig.valeurNominale,
            toleranceSuperieure: lig.toleranceSuperieure,
            toleranceInferieure: lig.toleranceInferieure,
            unite: lig.unite || '',
            limiteSpecTexte: lig.limiteSpecTexte || '',
            instruction: lig.instruction || '',
            observations: lig.observations || '',
            estCritique: lig.estCritique
          }))
        };
      });

    } catch (e) {
      toast.add({ severity: 'error', summary: 'Erreur', detail: 'Impossible de charger les données.', life: 4000 });
    } finally {
      isLoadingData.value = false;
    }
  };
  // ============================================================================

  const ajouterSection = () => {
    sections.value.push({ id: crypto.randomUUID(), isFromDb: false, typeSectionId: '', modeFreq: 'SANS', periodiciteId: null, freqNum: 1, typeVariable: 'HEURE', freqHours: 1, isNewFreq: false, nom: '', lignes: [] });
  };
  const supprimerSection = (id) => { sections.value = sections.value.filter(s => s.id !== id); };
  const mettreAJourSection = (index, updatedSection) => { sections.value[index] = updatedSection; };

  const ajouterLigneASection = (sectionIndex) => {
    if (sections.value[sectionIndex]) {
      if (!sections.value[sectionIndex].typeSectionId) {
        toast.add({ severity: 'warn', summary: 'Type de section requis', detail: 'Veuillez définir la nature de la section avant d\'ajouter une ligne.', life: 4000 });
        return;
      }
      const nouvelleLigne = { id: crypto.randomUUID(), isFromDb: false, typeCaracteristiqueId: null, typeControleId: null, moyenControleId: null, moyenTexteLibre: '', instrumentCode: null, libelleAffiche: '', valeurNominale: null, toleranceInferieure: null, toleranceSuperieure: null, unite: '', limiteSpecTexte: '', instruction: '', observations: '', estCritique: false };
      sections.value[sectionIndex].lignes.push(nouvelleLigne);
    }
  };

  const supprimerLigneASection = (sectionIndex, ligneId) => {
    if (sections.value[sectionIndex]) {
      sections.value[sectionIndex].lignes = sections.value[sectionIndex].lignes.filter(l => l.id !== ligneId);
    }
  };

  const normalizeId = (id) => (typeof id === 'string' && id.length <= 36 ? id : null);

  const validerSaisieValeurs = () => {
    const hasLignes = sections.value.some(section => (section.lignes || []).length > 0);
    if (!hasLignes) {
      toast.add({ severity: 'warn', summary: 'Saisie requise', detail: 'Veuillez ajouter au moins une ligne de contrôle.', life: 5000 });
      return false;
    }

    let hasIncompleteLines = false;
    sections.value.forEach(section => {
      (section.lignes || []).forEach(ligne => {
        // On ne vérifie QUE le type de contrôle, car la caractéristique peut être NULL
        if (!ligne.typeControleId) {
          hasIncompleteLines = true;
        }
      });
    });

    if (hasIncompleteLines) {
      toast.add({
        severity: 'error',
        summary: 'Ligne incomplète',
        detail: 'Veuillez définir le "Type de contrôle" pour toutes vos lignes, ou supprimez les lignes vides avant de valider.',
        life: 6000
      });
      return false;
    }

    return true;
  };
  const validerLegendeMoyens = () => {
    const hasCustomInstruments = sections.value.some(section =>
      section.lignes.some(ligne => /[\*~!@#$%^&]/.test(ligne.instrumentCode || ''))
    );
    if (hasCustomInstruments && !legendeMoyens.value?.trim()) {
      showLegendValidation.value = true;
      toast.add({ severity: 'warn', summary: '⚠️ Légende OBLIGATOIRE', detail: 'Vous utilisez du texte personnalisé (* *** etc.) - veuillez remplir la légende des moyens.', life: 5000 });
      return false;
    }
    showLegendValidation.value = false;
    return true;
  };

  // --- FONCTION MAJEURE : RÉCUPÈRE LES VRAIS IDs DE LA DB POUR ÉVITER LES CONFLITS ---
  const syncIdsFromDb = (dbPlanData) => {
    if (!dbPlanData || !dbPlanData.sections) return;

    // 1. On s'assure que les sections de la base sont triées par ordre d'affichage
    const dbSections = [...dbPlanData.sections].sort((a, b) => (a.ordreAffiche || 0) - (b.ordreAffiche || 0));

    sections.value.forEach((sec, sIdx) => {
      // 2. Correspondance STRICTE par position (1ère section UI = 1ère section DB)
      const dbSec = dbSections[sIdx];

      if (dbSec) {
        sec.id = dbSec.id;
        sec.isFromDb = true;
        sec.modeleSectionId = dbSec.modeleSectionId;

        const dbLignes = [...(dbSec.lignes || [])].sort((a, b) => (a.ordreAffiche || 0) - (b.ordreAffiche || 0));

        (sec.lignes || []).forEach((lig, lIdx) => {
          // 3. Correspondance STRICTE par position pour les lignes (1ère ligne UI = 1ère ligne DB)
          const dbLig = dbLignes[lIdx];
          if (dbLig) {
            lig.id = dbLig.id;
            lig.isFromDb = true;
            lig.modeleLigneSourceId = dbLig.modeleLigneSourceId;
          } else {
            lig.isFromDb = false; // C'est une ligne fraîchement ajoutée par l'utilisateur
          }
        });
      } else {
        sec.isFromDb = false;
      }
    });
  };

  const onEditorSubmit = async () => {
    if (isSaving.value) return;
    isSaving.value = true;

    try {
      if (!isEditMode.value && planId.value !== 'nouveau') {
        await onWizardGenerate();
        return;
      }

      if (isArchived.value) {
        await restaurerArchive();
        return;
      }

      if (!validerSaisieValeurs()) return;
      if (!validerLegendeMoyens()) return;

      if (plan.value?.statut === 'ACTIF') {
        versioningMode.value = 'new-version';
        showVersioningDialog.value = true;
      } else {
        await declencherSauvegarde();
      }
    } catch (error) {
      console.error(error);
    } finally {
      if (showVersioningDialog.value || plan.value?.statut !== 'ACTIF') {
        isSaving.value = false;
      }
    }
  };
  const sauvegarderBrouillonSilencieux = async () => {
    if (isCanceling.value || isSaving.value || plan.value?.statut === 'ACTIF' || isArchived.value) return;

    let currentPlanId = planId.value;

    try {
      if (currentPlanId === 'nouveau' && planCreationPayload.value) {
        const instRes = await qualityPlansService.instantiatePlan(planCreationPayload.value);
        currentPlanId = instRes.data.planId;
        planId.value = currentPlanId;

        // ⚠️ NOUVEAU : on note qu'on a créé un brouillon fantôme pendant cette session
        aEteCreePendantCetteSession.value = true;

        const newPlanRes = await qualityPlansService.getPlanById(currentPlanId);
        syncIdsFromDb(newPlanRes.data.data);
        planCreationPayload.value = null;
      }

      if (!currentPlanId || currentPlanId === 'nouveau') return;

      const sectionsPreparees = await prepareModeleDataAndFrequencies(
        sections.value,
        store.periodicites || [],
        async (payloadFreq) => {
          const res = await qualityPlansService.createPeriodicite(payloadFreq);
          store.periodicites.push({ id: res.data.periodiciteId || res.data.id, ...payloadFreq });
          return res;
        }
      );

      const payload = sectionsPreparees.map((s, idx) => {
        const originalSection = sections.value[idx];
        const tsMatch = store.typesSection.find(t => t.id === s.typeSectionId);
        const generatedLibelle = tsMatch ? tsMatch.libelle : (s.nom || 'SECTION SANS NOM');

        const lignesMappees = (s.lignes || []).map((l, lIdx) => {
          const originalLigne = originalSection.lignes[lIdx];
          return {
            id: originalLigne.isFromDb ? normalizeId(originalLigne.id) : null,
            modeleLigneSourceId: l.modeleLigneSourceId,
            ordreAffiche: lIdx + 1,
            typeCaracteristiqueId: l.typeCaracteristiqueId,
            typeControleId: l.typeControleId,
            moyenControleId: l.moyenControleId,
            moyenTexteLibre: l.moyenTexteLibre,
            instrumentCode: l.instrumentCode,
            valeurNominale: l.valeurNominale ?? null,
            toleranceSuperieure: l.toleranceSuperieure ?? null,
            toleranceInferieure: l.toleranceInferieure ?? null,
            unite: l.unite,
            limiteSpecTexte: l.limiteSpecTexte,
            observations: l.observations,
            instruction: l.instruction,
            estCritique: l.estCritique
          };
        });

        // ⚠️ LE NOUVEAU FILTRE INTELLIGENT
        const lignesValidesPourAutoSave = lignesMappees.filter(lig => {
          // 1. Si la ligne vient de la base de données (elle a un ID), on DOIT l'envoyer
          // Sinon, le backend va croire qu'on veut la supprimer.
          if (lig.id) return true;

          // 2. Si c'est une NOUVELLE ligne, on l'envoie seulement si son Type de Contrôle est rempli
          // (C'est ce champ qui causait l'erreur 400 Bad Request)
          return lig.typeControleId != null && lig.typeControleId !== '';
        });

        return {
          id: originalSection.isFromDb ? normalizeId(originalSection.id) : null,
          modeleSectionId: s.modeleSectionId,
          ordreAffiche: idx + 1,
          typeSectionId: s.typeSectionId,
          libelleSection: generatedLibelle,
          frequenceLibelle: s.periodiciteId ? (store.periodicites.find(p => p.id === s.periodiciteId)?.libelle || '') : '',
          periodiciteId: s.periodiciteId,
          lignes: lignesValidesPourAutoSave // On envoie les lignes protégées
        };
      });

      await mettreAJourValeurs(currentPlanId, payload, legendeMoyens.value, false);
      console.log("Auto-save réussi : Brouillon mis à jour proprement.");

    } catch (error) {
      console.error("L'auto-save a échoué. Tentative au prochain cycle...", error);
    }
  };

  const declencherSauvegarde = async () => {
    let currentPlanId = planId.value;

    if (currentPlanId === 'nouveau' && planCreationPayload.value) {
      try {

        const instRes = await qualityPlansService.instantiatePlan(planCreationPayload.value);
        currentPlanId = instRes.data.planId;
        planId.value = currentPlanId;
        router.replace(`/dev/fab/plans/editer/${currentPlanId}`);


        const newPlanRes = await qualityPlansService.getPlanById(currentPlanId);
        syncIdsFromDb(newPlanRes.data.data);

        planCreationPayload.value = null;
      } catch (err) {
        toast.add({ severity: 'error', summary: 'Erreur', detail: 'Impossible d\'instancier le brouillon', life: 6000 });
        throw err;
      }
    }

    await enregistrerValeurs(currentPlanId, true);
  };

  const enregistrerValeurs = async (currentPlanId, redirectToHub = true) => {
    try {
      const sectionsPreparees = await prepareModeleDataAndFrequencies(
        sections.value,
        store.periodicites || [],
        async (payloadFreq) => {
          const res = await qualityPlansService.createPeriodicite(payloadFreq);
          store.periodicites.push({ id: res.data.periodiciteId || res.data.id, ...payloadFreq });
          return res;
        }
      );

      const payload = sectionsPreparees.map((s, idx) => {
        const originalSection = sections.value[idx];
        const tsMatch = store.typesSection.find(t => t.id === s.typeSectionId);
        const generatedLibelle = tsMatch ? tsMatch.libelle : (s.nom || 'SECTION SANS NOM');

        return {
          id: originalSection.isFromDb ? normalizeId(originalSection.id) : null,
          modeleSectionId: s.modeleSectionId,
          ordreAffiche: idx + 1,
          typeSectionId: s.typeSectionId,
          libelleSection: generatedLibelle,
          frequenceLibelle: s.periodiciteId ? (store.periodicites.find(p => p.id === s.periodiciteId)?.libelle || '') : '',
          periodiciteId: s.periodiciteId,
          lignes: (s.lignes || []).map((l, lIdx) => {
            const originalLigne = originalSection.lignes[lIdx];

            return {
              id: originalLigne.isFromDb ? normalizeId(originalLigne.id) : null,
              modeleLigneSourceId: l.modeleLigneSourceId,
              ordreAffiche: lIdx + 1,
              typeCaracteristiqueId: l.typeCaracteristiqueId,
              typeControleId: l.typeControleId,
              moyenControleId: l.moyenControleId,
              moyenTexteLibre: l.moyenTexteLibre,
              instrumentCode: l.instrumentCode,
              valeurNominale: l.valeurNominale ?? null,
              toleranceSuperieure: l.toleranceSuperieure ?? null,
              toleranceInferieure: l.toleranceInferieure ?? null,
              unite: l.unite,
              limiteSpecTexte: l.limiteSpecTexte,
              observations: l.observations,
              instruction: l.instruction,
              estCritique: l.estCritique
            };
          })
        };
      });

      // On finalise ici : rendre le plan ACTIF
      await mettreAJourValeurs(currentPlanId, payload, legendeMoyens.value, true);

      toast.add({ severity: 'success', summary: 'Plan Activé', detail: 'Le plan est maintenant en production.', life: 4000 });

      if (redirectToHub) {
        isExitingEditor.value = true;
        router.push('/dev/hub-plans');
      } else {
        await chargerPlan(currentPlanId);
      }

    } catch (error) {
      console.error('Erreur sauvegarde:', error);
      toast.add({ severity: 'error', summary: 'Erreur', detail: 'Une erreur est survenue lors de la sauvegarde.', life: 4000 });
      throw error;
    }
  };

  const restaurerArchive = async () => {
    try {
      const res = await restaurerPlan({
        planArchiveId: planId.value,
        restaurePar: 'ADMIN',
        motifRestoration: 'Restauration manuelle depuis l\'éditeur'
      });

      toast.add({ severity: 'success', summary: 'Plan restauré', detail: 'Le plan a été réactivé avec succès.', life: 4000 });
      isExitingEditor.value = true;
      router.push('/dev/hub-plans');
    } catch (error) {
      console.error('Erreur restauration:', error);
      toast.add({ severity: 'error', summary: 'Erreur', detail: 'Une erreur est survenue lors de la restauration.', life: 4000 });
    }
  };

  const onVersioningConfirm = async (motif) => {
    isSaving.value = true;
    showVersioningDialog.value = false; // Fermer la modale immédiatement pour éviter le double-clic

    try {
      if (versioningMode.value === 'new-version') {

        // 1. Le backend clone la V1 et crée la V2 en base
        const newVersionPlan = await creerNouvelleVersionPlan({
          ancienId: planId.value,
          modifiePar: 'ADMIN',
          motifModification: motif || 'Modification de la structure du plan'
        });
        const newPlanId = newVersionPlan.data.planId;

        const clonedPlanRes = await qualityPlansService.getPlanById(newPlanId);

        // 3. On "vole" les nouveaux IDs de manière infaillible (par position)
        syncIdsFromDb(clonedPlanRes.data.data);

        // 4. On envoie les valeurs modifiées. Le Backend verra les VRAIS IDs et fera un UPDATE propre !
        await enregistrerValeurs(newPlanId, true);

      } else if (versioningMode.value === 'restore') {
        await restaurerArchive();
      }
    } catch (error) {
      console.error('Erreur versioning:', error);
      toast.add({ severity: 'error', summary: 'Erreur', detail: 'Une erreur est survenue lors de l\'opération de versioning.', life: 4000 });
    } finally {
      isSaving.value = false;
    }
  };
</script>

<style scoped>
  .page-transition {
    transition: opacity 0.5s ease, transform 0.5s ease;
  }

  .fade-enter, .fade-leave-to {
    opacity: 0;
    transform: translateY(10px);
  }

  .zoom-enter, .zoom-leave-to {
    transform: scale(0.95);
  }
</style>
