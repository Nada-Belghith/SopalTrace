<template>
  <div class="bg-slate-50 min-h-screen p-4 md:p-8 font-sans text-slate-800">
    <Toast position="top-right" />
    <ConfirmDialog />

    <VersioningDialog :visible="showVersioningDialog"
                      :mode="versioningMode"
                      :is-loading="isSaving"
                      @confirm="onVersioningConfirm"
                      @cancel="showVersioningDialog = false"
                      @update:visible="showVersioningDialog = $event" />

    <div class="max-w-[1600px] mx-auto">
      <div class="animate-in fade-in zoom-in-95 duration-500">

        <div class="flex flex-col md:flex-row justify-between items-start mb-8 gap-4">
          <div class="flex-1 min-w-0">
            <h1 class="text-3xl font-black text-slate-900 tracking-tight truncate">
              {{ headerTitle }}
            </h1>
            <p class="text-sm text-slate-500 mt-1 font-medium">{{ headerSubtitle }}</p>

            <div v-if="isEditMode" class="mt-4 flex flex-wrap items-center gap-3">
              <div class="inline-flex items-center gap-3 bg-blue-50/50 border border-blue-100 text-blue-800 px-4 py-2 rounded-xl shadow-sm max-w-full">
                <i class="pi pi-box text-blue-500 shrink-0"></i>
                <span class="font-mono font-bold truncate shrink-0">{{ codeAffiche }}</span>
                <span class="text-blue-300 shrink-0">|</span>
                <span class="font-semibold text-sm truncate">{{ plan?.designation || wizard.designationArticle }}</span>
              </div>

              <div class="inline-flex items-center gap-2 bg-slate-100 border border-slate-200 text-slate-700 px-4 py-2 rounded-xl shadow-sm shrink-0">
                <i class="pi pi-cog text-slate-400"></i>
                <span class="text-xs font-bold uppercase tracking-widest">Opération :</span>
                <span class="font-black">{{ plan?.operationCode || 'NON DÉFINIE' }}</span>
              </div>
            </div>
          </div>

          <div class="flex items-center gap-3 shrink-0">
            <div v-if="isEditMode" class="flex items-center gap-2 bg-white p-2 rounded-xl shadow-sm border border-slate-200">
              <span v-if="plan?.statut === 'BROUILLON'" class="px-4 py-1.5 bg-amber-50 text-amber-700 font-black text-[10px] uppercase rounded-lg border border-amber-200 tracking-widest"><i class="pi pi-pencil mr-1"></i> Brouillon</span>
              <span v-else-if="plan?.statut === 'ACTIF'" class="px-4 py-1.5 bg-emerald-50 text-emerald-700 font-black text-[10px] uppercase rounded-lg border border-emerald-200 tracking-widest"><i class="pi pi-check-circle mr-1"></i> Actif (Prod)</span>
              <span v-else-if="plan?.statut === 'ARCHIVE'" class="px-4 py-1.5 bg-red-50 text-red-700 font-black text-[10px] uppercase rounded-lg border border-red-200 tracking-widest"><i class="pi pi-box mr-1"></i> Archivé</span>

              <div class="px-4 py-1.5 bg-slate-100 text-slate-600 font-black text-[10px] uppercase rounded-lg border border-slate-200 tracking-widest">
                VERSION {{ plan?.version || 1 }}
              </div>
            </div>

            <button v-if="isEditMode" @click="onCloseEditor" class="text-slate-400 hover:text-red-500 transition-colors ml-2 bg-white border border-slate-200 p-2.5 rounded-xl shadow-sm hover:border-red-200 hover:bg-red-50">
              <i class="pi pi-times"></i>
            </button>
          </div>
        </div>

        <PlanWizardStep v-if="!isEditMode"
                        :wizard="wizard"
                        @load-model="onWizardGenerate" />

        <div v-else class="bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden">
          <div class="bg-[#1e293b] text-white px-5 py-4 flex justify-between items-center">
            <div class="flex items-center gap-3 font-bold tracking-wide text-sm">
              <i class="pi pi-sliders-v text-blue-400"></i> Éditeur de Structure du Plan
            </div>
          </div>

          <div v-if="isLoadingData" class="py-20 text-center text-blue-500">
            <i class="pi pi-spin pi-spinner text-4xl mb-4"></i>
            <p class="text-xs font-black uppercase tracking-widest">Chargement de l'arbre...</p>
          </div>

          <div v-else class="p-6 md:p-8">
            <div class="mb-4">
              <h3 class="text-[11px] font-black text-slate-500 uppercase tracking-widest">Structure des lignes de contrôle</h3>
            </div>

            <template v-if="sections.length === 0">
              <div class="p-8 text-center text-slate-400 text-sm italic bg-slate-50 rounded-lg border border-slate-200 mb-6">
                Cliquez sur "Créer une nouvelle section" pour commencer.
              </div>
            </template>

            <FabPlanSectionCard v-for="(section, index) in sections"
                                :key="section.id"
                                :section="section"
                                :index="index"
                                :periodicites="store.periodicites"
                                :is-archived="isArchived"
                                @add-ligne="ajouterLigneASection(index)"
                                @remove="supprimerSection(section.id)"
                                @remove-ligne="(ligneId) => supprimerLigneASection(index, ligneId)"
                                @update:section="(updatedSection) => mettreAJourSection(index, updatedSection)" />

            <div class="mt-2" v-if="!isArchived">
              <button @click="ajouterSection" class="w-full p-4 bg-slate-50 text-center border border-dashed border-slate-300 hover:border-blue-400 rounded-lg hover:bg-blue-50 transition-colors text-slate-500 hover:text-blue-600 text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2">
                <i class="pi pi-plus-circle text-lg"></i> Créer une nouvelle section
              </button>
            </div>

            <div v-if="hasCustomInstrumentsGlobal"
                 :class="[
                'mt-6 px-4 py-3 rounded-lg',
                showLegendValidation && !legendeMoyens
                  ? 'bg-yellow-50 border-2 border-yellow-300'
                  : 'bg-slate-50 border border-slate-200'
              ]">
              <div class="flex items-start gap-2 mb-2">
                <i :class="[
                    'pi text-base mt-0.5',
                    showLegendValidation && !legendeMoyens
                      ? 'pi-exclamation-circle text-yellow-600'
                      : 'pi-info-circle text-slate-500'
                  ]"></i>
                <div>
                  <label :class="[
                      'block text-[10px] font-black uppercase tracking-widest',
                      showLegendValidation && !legendeMoyens ? 'text-yellow-800' : 'text-slate-700'
                    ]">
                    {{ showLegendValidation && !legendeMoyens ? '⚠️ Légende OBLIGATOIRE' : 'Légende des moyens' }}
                  </label>
                  <p :class="[
                      'text-[9px] mt-0.5',
                      showLegendValidation && !legendeMoyens ? 'text-yellow-700' : 'text-slate-500'
                    ]">
                    Texte personnalisé utilisé - veuillez documenter les abréviations
                  </p>
                </div>
              </div>
              <textarea v-model="legendeMoyens"
                        :disabled="isArchived"
                        placeholder="Ex: PAC*=PAC512,PAC612"
                        rows="2"
                        :class="[
                  'w-full border rounded px-3 py-2 text-xs outline-none shadow-sm',
                  isArchived ? 'bg-slate-100 text-slate-500 cursor-not-allowed' : 'text-slate-700 bg-white border-slate-300 focus:border-blue-500',
                  showLegendValidation && !legendeMoyens && !isArchived ? 'bg-red-50 border-red-300 focus:border-red-500' : ''
                ]"></textarea>
              <p v-if="showLegendValidation && !legendeMoyens && !isArchived" class="text-[9px] text-red-600 font-bold mt-1">❌ Remplissez la légende avant d'enregistrer!</p>
            </div>
          </div>

          <div class="bg-slate-50 border-t border-slate-200 p-6 flex justify-end">
            <template v-if="isEditMode && plan?.statut === 'BROUILLON'">
              <div class="flex gap-3">
                <button @click="onSaveDraft"
                        :disabled="isSaving"
                        class="px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 shadow-sm">
                  <i v-if="isSaving" class="pi pi-spin pi-spinner"></i>
                  <i v-else class="pi pi-save"></i>
                  Enregistrer Brouillon
                </button>
                <button @click="onActivatePlan"
                        :disabled="isSaving"
                        class="px-6 py-3 bg-emerald-500 text-white rounded-lg hover:bg-emerald-600 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 shadow-sm font-bold">
                  <i v-if="isSaving" class="pi pi-spin pi-spinner"></i>
                  <i v-else class="pi pi-check-circle"></i>
                  Activer le Plan
                </button>
              </div>
            </template>
            <template v-else>
              <EditorActions :label="editorLabel"
                             loading-label="Traitement..."
                             :icon="editorIcon"
                             :variant="editorVariant"
                             :is-loading="isSaving"
                             @submit="onEditorSubmit"
                             @cancel="onEditorCancel" />
            </template>
          </div>
        </div>

      </div>
    </div>
  </div>
</template>

<script setup>
  import { ref, onMounted, watch, computed, onUnmounted } from 'vue';
  import { useRoute, useRouter, onBeforeRouteLeave } from 'vue-router';
  import { useToast } from 'primevue/usetoast';
  import Toast from 'primevue/toast';
  import { useConfirm } from 'primevue/useconfirm';

  import { qualityPlansService } from '@/services/qualityPlansService';
  import { usePlanVersioning } from '@/composables/useVersioning';
  import { usePlanWizard } from '@/composables/usePlanWizard';
  import { useFabModeleStore } from '@/stores/fabModeleStore';
  import { prepareModeleDataAndFrequencies } from '@/utils/modelMapper';

  import VersioningDialog from '@/components/Shared/VersioningDialog.vue';
  import PlanWizardStep from '@/components/QualityPlans/PlanWizardStep.vue';
  import FabPlanSectionCard from '@/components/Fabrication/FabPlanSectionCard.vue';
  import EditorActions from '@/components/Shared/EditorActions.vue';

  const route = useRoute();
  const router = useRouter();
  const toast = useToast();
  const confirm = useConfirm();
  const store = useFabModeleStore();
  const { creerNouvelleVersionPlan, mettreAJourValeurs, restaurerPlan } = usePlanVersioning();

  const wizard = usePlanWizard();
  const isGeneratingPlan = ref(false);

  const isFromWizard = ref(false);
  const planId = ref(route.params.id === 'nouveau' ? null : route.params.id);
  const plan = ref(null);
  const sections = ref([]);
  const legendeMoyens = ref('');
  const showLegendValidation = ref(false);
  const isLoadingData = ref(false);
  const isSaving = ref(false);

  const hasCustomInstrumentsGlobal = computed(() =>
    sections.value.some(section =>
      (section.lignes || []).some(ligne => /[\*~!@#$%^&]/.test(ligne.instrumentCode || ''))
    )
  );

  const isEditMode = computed(() => !!planId.value);
  const isArchived = computed(() => plan.value?.statut === 'ARCHIVE');

  const headerTitle = computed(() => {
    if (isFromWizard.value) return "Création d'un plan de Fabrication";
    if (plan.value && plan.value.statut === 'BROUILLON' && (plan.value.version || 0) <= 1) {
      return "Création d'un plan de Fabrication";
    }
    if (!isEditMode.value) return "Création d'un plan de Fabrication";
    if (isArchived.value) return "Restauration d'Archive";
    return 'Édition du Plan de Fabrication';
  });

  const headerSubtitle = computed(() => {
    if (isFromWizard.value) return "Configurez la structure du plan de fabrication.";
    if (plan.value && plan.value.statut === 'BROUILLON' && (plan.value.version || 0) <= 1) {
      return "Configurez la structure du plan de fabrication.";
    }
    if (!isEditMode.value) return "Configurez la structure du plan de Fabrication.";
    if (isArchived.value) return "Vous consultez une archive. Restaurer réactivera cette version en production.";
    return "Modifiez la structure. L'ancienne version sera archivée automatiquement.";
  });

  const codeAffiche = computed(() => plan.value?.codeArticleSage || wizard.codeArticleSage || '');

  const editorLabel = computed(() => {
    if (!isEditMode.value) return 'Générer le Plan';
    if (isArchived.value) return 'Restaurer ce Plan';
    if (plan.value?.statut === 'BROUILLON' && (plan.value?.version || 0) <= 1) return 'Enregistrer & Activer le Plan';
    if (plan.value?.statut === 'ACTIF') return 'Créer une Nouvelle Version';
    return 'Enregistrer & Activer le Plan';
  });

  const editorIcon = computed(() => {
    if (!isEditMode.value) return 'pi pi-check';
    if (isArchived.value) return 'pi pi-history';
    if (plan.value?.statut === 'BROUILLON' && (plan.value?.version || 0) <= 1) return 'pi pi-save';
    return plan.value?.statut === 'ACTIF' ? 'pi pi-history' : 'pi pi-save';
  });

  const editorVariant = computed(() => {
    if (!isEditMode.value) return 'success';
    if (isArchived.value) return 'warning';
    if (plan.value?.statut === 'BROUILLON' && (plan.value?.version || 0) <= 1) return 'success';
    if (plan.value?.statut === 'ACTIF') return 'warning';
    return 'success';
  });

  const isExitingEditor = ref(false);
  const isCanceling = ref(false);
  let autoSaveInterval = null;
  const planCreationPayload = ref(null);
  const aEteCreePendantCetteSession = ref(false);

  const onCloseEditor = async () => {
    await sauvegarderBrouillonSilencieux(true);
    isExitingEditor.value = true;
    router.push('/dev/hub-plans');
  };

  const onEditorCancel = () => {
    if (plan.value?.statut !== 'BROUILLON') {
      isExitingEditor.value = true;
      router.push('/dev/hub-plans');
      return;
    }

    confirm.require({
      message: 'Êtes-vous sûr de vouloir abandonner ce travail ? Ce brouillon et toutes ses données seront DÉFINITIVEMENT supprimés.',
      header: 'Supprimer le Brouillon',
      icon: 'pi pi-trash text-red-500',
      acceptLabel: 'Oui, Supprimer',
      rejectLabel: 'Annuler',
      acceptClass: 'p-button-danger',
      accept: async () => {
        isCanceling.value = true;
        isExitingEditor.value = true;

        try {
          if (planId.value && planId.value !== 'nouveau') {
            await qualityPlansService.deletePlan(planId.value);
            toast.add({ severity: 'success', summary: 'Brouillon effacé', detail: 'La base de données a été nettoyée avec succès.', life: 4000 });
          }
        } catch (error) {
          console.error("Erreur lors de la suppression du brouillon", error);
          toast.add({ severity: 'error', summary: 'Erreur', detail: 'Impossible de supprimer le brouillon.', life: 4000 });
        } finally {
          router.push('/dev/hub-plans');
        }
      }
    });
  };

  onBeforeRouteLeave(async (_to, _from) => {
    if (isCanceling.value || isExitingEditor.value) {
      return true;
    }
    await sauvegarderBrouillonSilencieux(true);
    return true;
  });

  const showVersioningDialog = ref(false);
  const versioningMode = ref('new-version');

  onMounted(async () => {
    if (!store.isDicosLoaded) await store.fetchDictionnaires();
    if (planId.value && planId.value !== 'nouveau') await chargerPlan(planId.value);

    autoSaveInterval = setInterval(() => {
      if (plan.value?.statut === 'BROUILLON' || planCreationPayload.value) {
        sauvegarderBrouillonSilencieux(false);
      }
    }, 30000);
  });

  onUnmounted(() => {
    if (autoSaveInterval) {
      clearInterval(autoSaveInterval);
    }
  });

  watch(legendeMoyens, (value) => {
    if (value?.trim()) showLegendValidation.value = false;
  });

  const preparerNouveauBrouillon = async (modeleId, codeArticle) => {
    const modRes = await qualityPlansService.getModeleById(modeleId);
    const data = modRes.data.data;
    plan.value = {
      statut: 'BROUILLON',
      codeArticleSage: codeArticle,
      designation: wizard.designationArticle.value,
      version: 1,
      operationCode: data.operationCode
    };
    planCreationPayload.value = {
      modeleSourceId: modeleId,
      codeArticleSage: codeArticle,
      designation: wizard.designationArticle.value,
      nom: '',
      creePar: 'ADMIN_QUALITE'
    };
    sections.value = mapModeleDataToSections(data);
    isFromWizard.value = true;
    planId.value = "nouveau";
    isGeneratingPlan.value = false;
  };

  const onWizardGenerate = async (payload) => {
    if (isGeneratingPlan.value) return;
    isGeneratingPlan.value = true;

    try {
      if (wizard.sourceType.value === 'MODELE') {
        const modeleId = wizard.selectedSourceId.value;
        const codeArticle = wizard.codeArticleSage.value;

        const resVal = await qualityPlansService.verifierEtatPlan(codeArticle, modeleId);
        const etat = resVal.data;

        if (etat.hasBrouillon) {
          toast.add({ severity: 'info', summary: 'Reprise', detail: 'Un brouillon existe déjà. Reprise en cours...', life: 4000 });
          planId.value = etat.brouillonId;
          isFromWizard.value = true;
          router.replace(`/dev/fab/plans/editer/${etat.brouillonId}`);
          await chargerPlan(etat.brouillonId);
        }
        else if (etat.hasActif) {
          confirm.require({
            message: `Un plan ACTIF (Version ${etat.actifVersion}) tourne actuellement en production. Voulez-vous créer une nouvelle version ? (L'ancienne sera automatiquement archivée lorsque vous activerez la nouvelle).`,
            header: 'Confirmation de Nouvelle Version',
            icon: 'pi pi-exclamation-circle text-blue-500',
            acceptLabel: 'Oui, Créer la nouvelle version',
            rejectLabel: 'Annuler',
            acceptClass: 'p-button-primary',
            accept: async () => {
              await preparerNouveauBrouillon(modeleId, codeArticle);
            },
            reject: () => {
              isGeneratingPlan.value = false;
            }
          });
        }
        else {
          await preparerNouveauBrouillon(modeleId, codeArticle);
        }
      } else {
        const res = await wizard.genererPlan();
        const newPlanId = res.data.planId;
        toast.add({ severity: 'success', summary: 'Succès', detail: 'Plan cloné.', life: 3000 });
        planId.value = newPlanId;
        router.replace(`/dev/fab/plans/editer/${newPlanId}`);
        await chargerPlan(newPlanId);
      }

    } catch (error) {
      console.error('Erreur génération:', error);
      isGeneratingPlan.value = false;
    }
  };

  const mapModeleDataToSections = (modeleModel) => {
    return (modeleModel.sections || []).map(sec => {
      let modeFreq = 'SANS';
      let periodiciteId = null;
      let freqNum = 1;
      let typeVariable = 'HEURE';
      let freqHours = 1;

      if (sec.frequenceLibelle) {
        const perMatch = store.periodicites.find(p => p.libelle === sec.frequenceLibelle);
        if (perMatch) {
          modeFreq = 'FIXE';
          periodiciteId = perMatch.id;
        } else {
          modeFreq = 'VARIABLE';
          const libelle = sec.frequenceLibelle.toLowerCase();

          if (libelle.includes('pièce') && libelle.includes('heure')) {
            typeVariable = 'HEURE';
            const match = libelle.match(/(\d+)\s*pièce.*\/\s*(\d+)\s*heure/);
            if (match) {
              freqNum = parseInt(match[1]);
              freqHours = parseInt(match[2]);
            } else {
              const pieceMatch = libelle.match(/(\d+)\s*pièce/);
              if (pieceMatch) {
                freqNum = parseInt(pieceMatch[1]);
                freqHours = 1;
              }
            }
          } else if (libelle.includes('série')) {
            typeVariable = 'SERIE';
            const serieMatch = libelle.match(/série de (\d+) pièces/);
            if (serieMatch) {
              freqNum = parseInt(serieMatch[1]);
            }
          }
        }
      }

      let typeSectionId = sec.typeSectionId || '';
      if (!typeSectionId && sec.libelleSection) {
        const secLib = sec.libelleSection.trim().toLowerCase();
        let bestMatch = null;
        let maxLength = -1;

        store.typesSection.forEach(t => {
          const tLib = (t.libelle || '').trim().toLowerCase();
          if (!tLib || secLib === 'section sans nom') return;

          if (secLib.includes(tLib)) {
            if (tLib.length > maxLength) {
              maxLength = tLib.length;
              bestMatch = t;
            }
          }
        });

        if (bestMatch) {
          typeSectionId = bestMatch.id;
        }
      }

      return {
        id: crypto.randomUUID(),
        isFromDb: false,
        modeleSectionId: sec.id,
        typeSectionId,
        modeFreq,
        periodiciteId,
        freqNum,
        typeVariable,
        freqHours,
        isNewFreq: false,
        nom: sec.libelleSection,
        // ⚠️ BOURCLIER ANTI-CRASH: Filtre les lignes nulles
        lignes: (sec.lignes || []).filter(lig => lig != null).map(lig => ({
          id: crypto.randomUUID(),
          isFromDb: false,
          modeleLigneSourceId: lig.id,
          typeCaracteristiqueId: lig.typeCaracteristiqueId,
          typeControleId: lig.typeControleId,
          moyenControleId: lig.moyenControleId,
          instrumentCode: lig.instrumentCode,
          moyenTexteLibre: lig.moyenTexteLibre || '',
          valeurNominale: lig.valeurNominale ?? null,
          toleranceSuperieure: lig.toleranceSuperieure ?? null,
          toleranceInferieure: lig.toleranceInferieure ?? null,
          unite: lig.unite || '',
          limiteSpecTexte: lig.limiteSpecTexte || '',
          instruction: lig.instruction || '',
          observations: lig.observations || '',
          estCritique: lig.estCritique,
          libelleAffiche: lig.libelleAffiche
        }))
      };
    });
  };

  const chargerPlan = async (id) => {
    isLoadingData.value = true;
    try {
      const res = await qualityPlansService.getPlanById(id);
      const data = res.data.data;
      plan.value = data;
      legendeMoyens.value = data.legendeMoyens || '';

      const sectionsTriees = [...(data.sections || [])].sort((a, b) =>
        (a.ordreAffiche || 0) - (b.ordreAffiche || 0)
      );

      sections.value = sectionsTriees.map(sec => {

        let modeFreq = 'SANS';
        let periodiciteId = null;
        let freqNum = 1;
        let typeVariable = 'HEURE';
        let freqHours = 1;

        if (sec.frequenceLibelle) {
          const perMatch = store.periodicites.find(p => p.libelle === sec.frequenceLibelle);
          if (perMatch) {
            modeFreq = 'FIXE';
            periodiciteId = perMatch.id;
          } else {
            modeFreq = 'VARIABLE';
            const libelle = sec.frequenceLibelle.toLowerCase();

            if (libelle.includes('pièce') && libelle.includes('heure')) {
              typeVariable = 'HEURE';
              const match = libelle.match(/(\d+)\s*pièce.*\/\s*(\d+)\s*heure/);
              if (match) {
                freqNum = parseInt(match[1]);
                freqHours = parseInt(match[2]);
              } else {
                const pieceMatch = libelle.match(/(\d+)\s*pièce/);
                if (pieceMatch) {
                  freqNum = parseInt(pieceMatch[1]);
                  freqHours = 1;
                }
              }
            } else if (libelle.includes('série')) {
              typeVariable = 'SERIE';
              const serieMatch = libelle.match(/série de (\d+) pièces/);
              if (serieMatch) {
                freqNum = parseInt(serieMatch[1]);
              }
            }
          }
        }

        let typeSectionId = sec.typeSectionId || '';
        if (!typeSectionId && sec.libelleSection) {
          const secLib = sec.libelleSection.trim().toLowerCase();
          let bestMatch = null;
          let maxLength = -1;

          store.typesSection.forEach(t => {
            const tLib = (t.libelle || '').trim().toLowerCase();
            if (!tLib || secLib === 'section sans nom') return;

            if (secLib.includes(tLib)) {
              if (tLib.length > maxLength) {
                maxLength = tLib.length;
                bestMatch = t;
              }
            }
          });

          if (bestMatch) {
            typeSectionId = bestMatch.id;
          }
        }

        // ⚠️ BOURCLIER ANTI-CRASH: Filtre les lignes nulles
        const lignesTriees = [...(sec.lignes || [])]
          .filter(lig => lig != null)
          .sort((a, b) => (a.ordreAffiche || 0) - (b.ordreAffiche || 0));

        return {
          id: sec.id,
          isFromDb: true,
          typeSectionId,
          modeFreq,
          periodiciteId,
          freqNum,
          typeVariable,
          freqHours,
          isNewFreq: false,
          nom: sec.libelleSection,
          lignes: lignesTriees.map(lig => ({
            id: lig.id,
            isFromDb: true,
            typeCaracteristiqueId: lig.typeCaracteristiqueId,
            typeControleId: lig.typeControleId,
            moyenControleId: lig.moyenControleId,
            instrumentCode: lig.instrumentCode,
            moyenTexteLibre: lig.moyenTexteLibre || '',
            valeurNominale: lig.valeurNominale,
            toleranceSuperieure: lig.toleranceSuperieure,
            toleranceInferieure: lig.toleranceInferieure,
            unite: lig.unite || '',
            limiteSpecTexte: lig.limiteSpecTexte || '',
            instruction: lig.instruction || '',
            observations: lig.observations || '',
            estCritique: lig.estCritique,
            libelleAffiche: lig.libelleAffiche
          }))
        };
      });

    } catch (e) {
      toast.add({ severity: 'error', summary: 'Erreur', detail: 'Impossible de charger les données.', life: 4000 });
    } finally {
      isLoadingData.value = false;
    }
  };

  const ajouterSection = () => {
    sections.value.push({ id: crypto.randomUUID(), isFromDb: false, typeSectionId: '', modeFreq: 'SANS', periodiciteId: null, freqNum: 1, typeVariable: 'HEURE', freqHours: 1, isNewFreq: false, nom: '', lignes: [] });
  };
  const supprimerSection = (id) => { sections.value = sections.value.filter(s => s.id !== id); };
  const mettreAJourSection = (index, updatedSection) => { sections.value[index] = updatedSection; };

  const ajouterLigneASection = (sectionIndex) => {
    if (sections.value[sectionIndex]) {
      if (!sections.value[sectionIndex].typeSectionId) {
        toast.add({ severity: 'warn', summary: 'Type de section requis', detail: 'Veuillez définir la nature de la section avant d\'ajouter une ligne.', life: 4000 });
        return;
      }
      const nouvelleLigne = {
        id: crypto.randomUUID(),
        isFromDb: false,
        modeleLigneSourceId: null,
        typeCaracteristiqueId: null,
        typeControleId: null,
        moyenControleId: null,
        moyenTexteLibre: '',
        instrumentCode: null,
        libelleAffiche: '',
        valeurNominale: null,
        toleranceInferieure: null,
        toleranceSuperieure: null,
        unite: '',
        limiteSpecTexte: '',
        instruction: '',
        observations: '',
        estCritique: false
      };

      sections.value[sectionIndex].lignes.push(nouvelleLigne);
    }
  };

  const supprimerLigneASection = (sectionIndex, ligneId) => {
    if (sections.value[sectionIndex]) {
      sections.value[sectionIndex].lignes = sections.value[sectionIndex].lignes.filter(l => l.id !== ligneId);
    }
  };

  const normalizeId = (id) => (typeof id === 'string' && id.length <= 36 ? id : null);

  const validerSaisieValeurs = () => {
    const hasLignes = sections.value.some(section => (section.lignes || []).length > 0);
    if (!hasLignes) {
      toast.add({ severity: 'warn', summary: 'Saisie requise', detail: 'Veuillez ajouter au moins une ligne de contrôle.', life: 5000 });
      return false;
    }

    let hasMissingTypeControle = false;
    let hasMissingActivationFields = false;

    sections.value.forEach(section => {
      (section.lignes || []).forEach(ligne => {
        if (!ligne.typeControleId) {
          hasMissingTypeControle = true;
        }

        const hasValeurNominale =
          ligne.valeurNominale !== null &&
          ligne.valeurNominale !== undefined &&
          ligne.valeurNominale !== '';

        if (hasValeurNominale) {
          const uniteMissing = !`${ligne.unite || ''}`.trim();
          const tolSupMissing = ligne.toleranceSuperieure === null || ligne.toleranceSuperieure === undefined;
          const tolInfMissing = ligne.toleranceInferieure === null || ligne.toleranceInferieure === undefined;

          if (tolSupMissing || tolInfMissing) {
            hasMissingActivationFields = true;
          }
        }
      });
    });

    if (hasMissingTypeControle) {
      toast.add({
        severity: 'error',
        summary: 'Ligne incomplète',
        detail: 'Veuillez définir le "Type de contrôle" pour toutes vos lignes, ou supprimez les lignes vides avant d\'activer le plan.',
        life: 6000
      });
      return false;
    }

    if (hasMissingActivationFields) {
      toast.add({
        severity: 'error',
        summary: 'Champs obligatoires manquants',
        detail: 'Si une valeur nominale est saisie, renseignez aussi Tolérance min, Tolérance max.',
        life: 7000
      });
      return false;
    }

    return true;
  };

  const validerLegendeMoyens = () => {
    const hasCustomInstruments = sections.value.some(section =>
      section.lignes.some(ligne => /[\*~!@#$%^&]/.test(ligne.instrumentCode || ''))
    );
    if (hasCustomInstruments && !legendeMoyens.value?.trim()) {
      showLegendValidation.value = true;
      toast.add({ severity: 'warn', summary: '⚠️ Légende OBLIGATOIRE', detail: 'Vous utilisez du texte personnalisé (* *** etc.) - veuillez remplir la légende des moyens.', life: 5000 });
      return false;
    }
    showLegendValidation.value = false;
    return true;
  };

  const syncIdsFromDb = (dbPlanData) => {
    if (!dbPlanData || !dbPlanData.sections) return;

    sections.value.forEach((sec, sIdx) => {
      const dbSec = dbPlanData.sections.find(ds => ds.ordreAffiche === (sIdx + 1));

      if (dbSec) {
        sec.id = dbSec.id;
        sec.isFromDb = true;
        sec.modeleSectionId = dbSec.modeleSectionId;

        (sec.lignes || []).forEach((lig, lIdx) => {
          const dbLig = (dbSec.lignes || []).find(dl => dl.ordreAffiche === (lIdx + 1));

          if (dbLig) {
            lig.id = dbLig.id;
            lig.isFromDb = true;
            lig.modeleLigneSourceId = dbLig.modeleLigneSourceId;
          } else {
            lig.isFromDb = false;
          }
        });
      } else {
        sec.isFromDb = false;
      }
    });
  };

  // ⭐ FONCTION UTILITAIRE (Pour éviter les erreurs 500 sur les tolérances)
  const sanitizeMesurements = (ligne) => {
    const hasValeur = ligne.valeurNominale != null && ligne.valeurNominale !== '';
    const hasTolSup = ligne.toleranceSuperieure != null && ligne.toleranceSuperieure !== '';
    const hasTolInf = ligne.toleranceInferieure != null && ligne.toleranceInferieure !== '';

    // Si valeur nominale est présente MAIS tolérances manquent = neutraliser tout pour brouillon
    if (hasValeur && (!hasTolSup || !hasTolInf)) {
      return {
        valeurNominale: null,
        toleranceSuperieure: null,
        toleranceInferieure: null
      };
    }

    return {
      valeurNominale: hasValeur ? ligne.valeurNominale : null,
      toleranceSuperieure: hasTolSup ? ligne.toleranceSuperieure : null,
      toleranceInferieure: hasTolInf ? ligne.toleranceInferieure : null
    };
  };

  const sauvegarderBrouillonSilencieux = async (afficherToast = false) => {
    if (isCanceling.value || isSaving.value || plan.value?.statut === 'ACTIF' || isArchived.value) return;

    let currentPlanId = planId.value;

    try {
      if (currentPlanId === 'nouveau' && planCreationPayload.value) {
        const instRes = await qualityPlansService.instantiatePlan(planCreationPayload.value);
        currentPlanId = instRes.data.planId;
        planId.value = currentPlanId;
        aEteCreePendantCetteSession.value = true;
        const newPlanRes = await qualityPlansService.getPlanById(currentPlanId);
        syncIdsFromDb(newPlanRes.data.data);
        planCreationPayload.value = null;
      }

      if (!currentPlanId || currentPlanId === 'nouveau') return;

      const sectionsPreparees = await prepareModeleDataAndFrequencies(sections.value, store.periodicites, async (payload) => {
        const res = await qualityPlansService.createPeriodicite(payload);
        store.periodicites.push({ id: res.data.periodiciteId || res.data.id, ...payload });
        return res;
      });

      const payload = sectionsPreparees.map((s, idx) => {
        const originalSection = sections.value[idx];
        const tsMatch = store.typesSection.find(t => t.id === s.typeSectionId);

        const lignesMappees = (s.lignes || []).map((l, lIdx) => {
          const originalLigne = originalSection.lignes[lIdx];
          const mesurements = sanitizeMesurements(l);

          const caractMatch = (store.typesCaracteristique || store.caracteristiques || []).find(c => c.id === l.typeCaracteristiqueId);
          const nomCaract = caractMatch?.libelle || 'Caractéristique sans nom';

          return {
            id: originalLigne.isFromDb ? normalizeId(originalLigne.id) : null,
            modeleLigneSourceId: l.modeleLigneSourceId,
            ordreAffiche: lIdx + 1,
            typeCaracteristiqueId: l.typeCaracteristiqueId || null,
            typeControleId: l.typeControleId || null,
            moyenControleId: l.moyenControleId || null,
            instrumentCode: l.instrumentCode,
            moyenTexteLibre: l.moyenTexteLibre,
            valeurNominale: mesurements.valeurNominale,
            toleranceSuperieure: mesurements.toleranceSuperieure,
            toleranceInferieure: mesurements.toleranceInferieure,
            unite: l.unite || '',
            limiteSpecTexte: l.limiteSpecTexte || '',
            instruction: l.instruction || '',
            observations: l.observations || '',
            estCritique: l.estCritique,
            libelleAffiche: (l.libelleAffiche || nomCaract).trim()
          };
        });

        return {
          id: originalSection.isFromDb ? normalizeId(originalSection.id) : null,
          modeleSectionId: originalSection.modeleSectionId,
          ordreAffiche: idx + 1,
          typeSectionId: s.typeSectionId,
          libelleSection: tsMatch ? tsMatch.libelle : (s.libelleSection || 'SECTION SANS NOM'),
          frequenceLibelle: s.periodiciteId ? store.periodicites.find(p => p.id === s.periodiciteId)?.libelle : '',
          periodiciteId: s.periodiciteId,
          lignes: lignesMappees
        };
      });

      await mettreAJourValeurs(currentPlanId, payload, legendeMoyens.value, false);

      if (afficherToast) {
        toast.add({ severity: 'info', summary: 'Brouillon enregistré', detail: 'Vos données (même incomplètes) sont sauvegardées.', life: 3000 });
      }
    } catch (error) {
      console.error("L'auto-save a échoué.", error);
    }
  };

  const declencherSauvegarde = async () => {
    let currentPlanId = planId.value;

    if (currentPlanId === 'nouveau' && planCreationPayload.value) {
      try {
        const instRes = await qualityPlansService.instantiatePlan(planCreationPayload.value);
        currentPlanId = instRes.data.planId;
        planId.value = currentPlanId;
        router.replace(`/dev/fab/plans/editer/${currentPlanId}`);

        const newPlanRes = await qualityPlansService.getPlanById(currentPlanId);
        syncIdsFromDb(newPlanRes.data.data);

        planCreationPayload.value = null;
      } catch (err) {
        toast.add({ severity: 'error', summary: 'Erreur', detail: 'Impossible d\'instancier le brouillon', life: 6000 });
        throw err;
      }
    }

    await enregistrerValeurs(currentPlanId, true);
  };

  const enregistrerValeurs = async (currentPlanId, redirectToHub = true) => {
    try {
      const sectionsPreparees = await prepareModeleDataAndFrequencies(
        sections.value,
        store.periodicites || [],
        async (payloadFreq) => {
          const res = await qualityPlansService.createPeriodicite(payloadFreq);
          store.periodicites.push({ id: res.data.periodiciteId || res.data.id, ...payloadFreq });
          return res;
        }
      );

      const payload = sectionsPreparees.map((s, idx) => {
        const originalSection = sections.value[idx];
        const tsMatch = store.typesSection.find(t => t.id === s.typeSectionId);
        const generatedLibelle = tsMatch ? tsMatch.libelle : (s.libelleSection || 'SECTION SANS NOM');

        return {
          id: originalSection.isFromDb ? normalizeId(originalSection.id) : null,
          modeleSectionId: originalSection.modeleSectionId,
          ordreAffiche: idx + 1,
          typeSectionId: s.typeSectionId,
          libelleSection: generatedLibelle,
          frequenceLibelle: s.periodiciteId ? (store.periodicites.find(p => p.id === s.periodiciteId)?.libelle || '') : '',
          periodiciteId: s.periodiciteId,
          lignes: (s.lignes || []).map((l, lIdx) => {
            const originalLigne = originalSection.lignes[lIdx];
            const caractMatch = (store.typesCaracteristique || store.caracteristiques || []).find(c => c.id === l.typeCaracteristiqueId);
            const nomCaract = caractMatch?.libelle || 'Caractéristique sans nom';
            const mesurements = sanitizeMesurements(l);

            return {
              id: originalLigne.isFromDb ? normalizeId(originalLigne.id) : null,
              modeleLigneSourceId: l.modeleLigneSourceId,
              ordreAffiche: lIdx + 1,
              typeCaracteristiqueId: l.typeCaracteristiqueId,
              typeControleId: l.typeControleId,
              moyenControleId: l.moyenControleId,
              moyenTexteLibre: l.moyenTexteLibre,
              instrumentCode: l.instrumentCode,
              valeurNominale: mesurements.valeurNominale,
              toleranceSuperieure: mesurements.toleranceSuperieure,
              toleranceInferieure: mesurements.toleranceInferieure,
              unite: l.unite,
              limiteSpecTexte: l.limiteSpecTexte,
              observations: l.observations,
              instruction: l.instruction,
              estCritique: l.estCritique,
              libelleAffiche: (l.libelleAffiche || nomCaract).trim()
            };
          })
        };
      });

      await mettreAJourValeurs(currentPlanId, payload, legendeMoyens.value, true);

      toast.add({ severity: 'success', summary: 'Plan Activé', detail: 'Le plan est maintenant en production.', life: 4000 });

      if (redirectToHub) {
        isExitingEditor.value = true;
        router.push('/dev/hub-plans');
      } else {
        await chargerPlan(currentPlanId);
      }

    } catch (error) {
      console.error('Erreur sauvegarde:', error);
      toast.add({ severity: 'error', summary: 'Erreur', detail: 'Une erreur est survenue lors de la sauvegarde.', life: 4000 });
      throw error;
    }
  };

  const onSaveDraft = async () => {
    if (isSaving.value) return;
    isSaving.value = true;

    try {
      await sauvegarderBrouillonSilencieux(true);
      isExitingEditor.value = true;
      router.push('/dev/hub-plans');
    } catch (error) {
      console.error(error);
    } finally {
      isSaving.value = false;
    }
  };

  const onActivatePlan = async () => {
    if (isSaving.value) return;
    isSaving.value = true;

    try {
      if (!validerSaisieValeurs()) return;
      if (!validerLegendeMoyens()) return;

      await declencherSauvegarde();
    } catch (error) {
      console.error(error);
    } finally {
      isSaving.value = false;
    }
  };

  const onEditorSubmit = async () => {
    if (isSaving.value) return;
    isSaving.value = true;

    try {
      if (!isEditMode.value && planId.value !== 'nouveau') {
        await onWizardGenerate();
        return;
      }

      if (isArchived.value) {
        await restaurerArchive();
        return;
      }

      if (!validerSaisieValeurs()) return;
      if (!validerLegendeMoyens()) return;

      if (plan.value?.statut === 'ACTIF') {
        versioningMode.value = 'new-version';
        showVersioningDialog.value = true;
      } else {
        await declencherSauvegarde();
      }
    } catch (error) {
      console.error(error);
    } finally {
      if (showVersioningDialog.value || plan.value?.statut !== 'ACTIF') {
        isSaving.value = false;
      }
    }
  };

  const restaurerArchive = async () => {
    try {
      const res = await restaurerPlan({
        planArchiveId: planId.value,
        restaurePar: 'ADMIN',
        motifRestoration: 'Restauration manuelle depuis l\'éditeur'
      });

      toast.add({ severity: 'success', summary: 'Plan restauré', detail: 'Le plan a été réactivé avec succès.', life: 4000 });
      isExitingEditor.value = true;
      router.push('/dev/hub-plans');
    } catch (error) {
      console.error('Erreur restauration:', error);
      toast.add({ severity: 'error', summary: 'Erreur', detail: 'Une erreur est survenue lors de la restauration.', life: 4000 });
    }
  };

  const onVersioningConfirm = async (motif) => {
    isSaving.value = true;
    showVersioningDialog.value = false;

    try {
      if (versioningMode.value === 'new-version') {
        const newVersionPlan = await creerNouvelleVersionPlan({
          ancienId: planId.value,
          modifiePar: 'ADMIN',
          motifModification: motif || 'Modification de la structure du plan'
        });
        const newPlanId = newVersionPlan.data.planId;
        const clonedPlanRes = await qualityPlansService.getPlanById(newPlanId);
        syncIdsFromDb(clonedPlanRes.data.data);
        await enregistrerValeurs(newPlanId, true);
      } else if (versioningMode.value === 'restore') {
        await restaurerArchive();
      }
    } catch (error) {
      console.error('Erreur versioning:', error);
      toast.add({ severity: 'error', summary: 'Erreur', detail: 'Une erreur est survenue lors de l\'opération de versioning.', life: 4000 });
    } finally {
      isSaving.value = false;
    }
  };
</script>

<style scoped>
  .page-transition {
    transition: opacity 0.5s ease, transform 0.5s ease;
  }

  .fade-enter, .fade-leave-to {
    opacity: 0;
    transform: translateY(10px);
  }

  .zoom-enter, .zoom-leave-to {
    transform: scale(0.95);
  }
</style>
