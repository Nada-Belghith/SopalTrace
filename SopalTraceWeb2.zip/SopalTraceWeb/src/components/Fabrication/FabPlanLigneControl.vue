<template>
  <tr v-if="ligne" class="hover:bg-blue-50/20 transition-colors group">

    <td class="p-2 border-r border-slate-200 align-top w-[22%]">
      <select v-model="ligne.typeCaracteristiqueId" :disabled="isArchived" class="w-full bg-white border border-slate-200 rounded px-2 py-1.5 text-[11px] text-slate-700 outline-none focus:border-blue-500 cursor-pointer font-medium disabled:opacity-60 disabled:bg-slate-50">
        <option :value="null" disabled>-- Caractéristique * --</option>
        <option v-for="tc in (store.typesCaracteristique || store.caracteristiques || [])" :key="tc.id" :value="tc.id">{{ tc.libelle }}</option>
      </select>
    </td>

    <td class="p-2 border-r border-slate-200 bg-blue-50/40 align-top text-center w-[12%]">
      <input v-model="ligne.valeurNominale" type="text" placeholder="Ex: Ø13"
             :disabled="isVisuel || isArchived"
             :class="isVisuel || isArchived ? 'opacity-50 cursor-not-allowed bg-slate-100' : 'bg-white'"
             class="w-full text-center font-semibold text-slate-700 border border-slate-300 rounded px-2 py-1 outline-none focus:border-blue-500 text-sm transition-opacity">
    </td>

    <td class="p-2 border-r border-slate-200 align-top text-center w-[14%] min-w-[170px]">
      <div class="grid grid-cols-2 gap-2">
        <input v-model.number="ligne.toleranceInferieure"
               @input="updateLimiteSpecTexte"
               type="number"
               step="any"
               placeholder="Min"
               :disabled="isVisuel || isArchived"
               :class="isVisuel || isArchived ? 'opacity-50 cursor-not-allowed bg-slate-100' : 'bg-white'"
               class="w-full text-center font-semibold text-slate-700 border border-slate-300 rounded px-2 py-1.5 outline-none focus:border-slate-500 text-sm transition-opacity">
        <input v-model.number="ligne.toleranceSuperieure"
               @input="updateLimiteSpecTexte"
               type="number"
               step="any"
               placeholder="Max"
               :disabled="isVisuel || isArchived"
               :class="isVisuel || isArchived ? 'opacity-50 cursor-not-allowed bg-slate-100' : 'bg-white'"
               class="w-full text-center font-semibold text-slate-700 border border-slate-300 rounded px-2 py-1.5 outline-none focus:border-slate-500 text-sm transition-opacity">
      </div>
    </td>

    <td class="p-2 border-r border-slate-200 align-top w-[12%]">
      <select v-model="ligne.typeControleId" :disabled="isArchived" class="w-full bg-white border border-slate-200 rounded px-2 py-1.5 text-[11px] text-slate-700 outline-none focus:border-blue-500 cursor-pointer disabled:opacity-60 disabled:bg-slate-50">
        <option :value="null" disabled>-- Type * --</option>
        <option v-for="tco in (store.typesControle || [])" :key="tco.id" :value="tco.id">{{ tco.code }}</option>
      </select>
    </td>

    <td class="p-2 border-r border-slate-200 align-top w-[12%]">
      <select v-model="ligne.moyenControleId" :disabled="isArchived" class="w-full bg-white border border-slate-200 rounded px-2 py-1.5 text-[11px] text-slate-700 outline-none focus:border-blue-500 cursor-pointer disabled:opacity-60 disabled:bg-slate-50">
        <option :value="null">-- Moyen --</option>
        <option v-for="mco in (store.moyensControle || [])" :key="mco.id" :value="mco.id">{{ mco.libelle }}</option>
      </select>
    </td>

    <!-- Code instrument (Éditable - Combobox) -->
    <td class="p-2 border-r border-slate-200 align-top w-[12%]">
      <div class="flex gap-1 items-center">
        <select @change="(e) => { if (e.target.value) ligne.instrumentCode = e.target.value; e.target.value = ''; }"
                :disabled="isVisuel"
                :class="isVisuel ? 'opacity-50 cursor-not-allowed bg-slate-100' : 'bg-white cursor-pointer'"
                class="flex-1 border border-slate-200 rounded px-2 py-1.5 text-[11px] text-slate-700 outline-none focus:border-blue-500 transition-opacity">
          <option value="">-- Outil --</option>
          <option v-for="ins in (store.instruments || [])" :key="ins.codeInstrument" :value="ins.codeInstrument">
            {{ ins.codeInstrument }}
          </option>
        </select>
        <input v-model="ligne.instrumentCode" type="text" placeholder="Perso"
               :disabled="isVisuel"
               :class="isVisuel ? 'opacity-50 cursor-not-allowed bg-slate-100' : 'bg-white'"
               class="flex-1 border border-slate-200 rounded px-2 py-1.5 text-[10px] text-slate-700 outline-none focus:border-blue-500 transition-opacity">
      </div>
    </td>

    <td class="p-2 border-r border-slate-200 align-top w-[18%] min-w-[180px]">
      <input v-model="ligne.observations" type="text" placeholder="Infos (Optionnel)..." :disabled="isArchived"
             class="w-full bg-white border border-slate-200 rounded px-2 py-1.5 text-xs text-slate-600 outline-none focus:border-blue-500 disabled:opacity-60 disabled:bg-slate-50">
    </td>

    <td v-if="!isArchived" class="p-2 align-middle text-center opacity-0 group-hover:opacity-100 transition-opacity w-8">
      <button @click="$emit('remove', ligne.id)" class="text-slate-300 hover:text-red-500 transition-colors p-2 rounded-lg hover:bg-red-50" title="Supprimer cette ligne">
        <i class="pi pi-trash"></i>
      </button>
    </td>
    <td v-else class="p-2 w-8"></td>
  </tr>
</template>

<script setup>
  import { computed, watch } from 'vue';
  import { useFabModeleStore } from '@/stores/fabModeleStore';

  const props = defineProps({
    ligne: { type: Object, required: true },
    section: { type: Object, required: true },
    isArchived: { type: Boolean, default: false }
  });

  defineEmits(['remove']);

  const store = useFabModeleStore();

  // ⚠️ SECURITE
  const isVisuel = computed(() => {
    if (!props.ligne) return false;

    const typeCtrl = (store.typesControle || []).find(t => t.id === props.ligne.typeControleId);
    return typeCtrl?.code === 'VISUEL';
  });

  watch(isVisuel, (devenuVisuel) => {
    if (devenuVisuel && props.ligne) {
      props.ligne.instrumentCode = null;
      props.ligne.moyenTexteLibre = '';
      props.ligne.valeurNominale = null;
      props.ligne.toleranceInferieure = null;
      props.ligne.toleranceSuperieure = null;
      props.ligne.limiteSpecTexte = '';
    }
  });

  const updateLimiteSpecTexte = () => {
    if (!props.ligne) return;

    const min = props.ligne.toleranceInferieure;
    const max = props.ligne.toleranceSuperieure;

    if (min === null || min === undefined || min === '' || max === null || max === undefined || max === '') {
      props.ligne.limiteSpecTexte = '';
      return;
    }

    props.ligne.limiteSpecTexte = `${min} / ${max}`;
  };
</script>
