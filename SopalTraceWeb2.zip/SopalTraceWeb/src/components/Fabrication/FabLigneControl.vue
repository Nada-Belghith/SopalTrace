<template>
  <tr class="hover:bg-blue-50/20 transition-colors group">
    <td class="p-2 align-top">
      <div class="flex items-center gap-1">
        <select v-model="ligne.typeCaracteristiqueId" :disabled="isReadOnly" :class="['w-full rounded px-2 py-1.5 text-[11px] outline-none focus:border-blue-500', isReadOnly ? 'bg-slate-100 border-slate-200 text-slate-500 cursor-not-allowed' : 'bg-white border border-slate-200 text-slate-700 cursor-pointer']">
          <option :value="null" disabled>-- Caractéristique * --</option>
          <option v-for="car in (store.caracteristiques || store.typesCaracteristiques || store.typesCaracteristique || [])" :key="car.id" :value="car.id">
            {{ car.libelle }}
          </option>
        </select>
        
        <button v-if="!isReadOnly"
          @click="showAddCaractModal = true" 
          class="p-1.5 bg-blue-50 text-blue-600 hover:bg-blue-500 hover:text-white rounded border border-blue-200 transition-colors"
          title="Créer une nouvelle caractéristique"
        >
          <i class="pi pi-plus text-xs"></i>
        </button>
      </div>

      <Dialog v-model:visible="showAddCaractModal" header="Nouvelle Caractéristique" :modal="true" :style="{ width: '400px' }">
        <div class="flex flex-col gap-4 pt-2">
          <div class="flex flex-col gap-1">
            <label class="text-xs font-bold text-slate-700">Libellé (Nom) <span class="text-red-500">*</span></label>
            <InputText v-model="newCaract.libelle" placeholder="Ex: Rayon de courbure" class="w-full text-sm" />
          </div>
          <div class="flex items-center gap-2">
            <Checkbox v-model="newCaract.estNumerique" :binary="true" inputId="numCheck" />
            <label for="numCheck" class="text-xs font-bold text-slate-700 cursor-pointer">C'est une valeur numérique mesurable</label>
          </div>
          <div class="flex flex-col gap-1" v-if="newCaract.estNumerique">
            <label class="text-xs font-bold text-slate-700">Unité par défaut (Optionnel)</label>
            <InputText v-model="newCaract.uniteDefaut" placeholder="Ex: mm, kg, °C..." class="w-full text-sm" />
          </div>
        </div>
        <template #footer>
          <Button label="Annuler" icon="pi pi-times" text @click="showAddCaractModal = false" class="p-button-sm text-slate-500" />
          <Button label="Créer et Sélectionner" icon="pi pi-check" @click="creerCaracteristique" :loading="isSavingCaract" :disabled="!newCaract.libelle" class="p-button-sm p-button-primary" />
        </template>
      </Dialog>
    </td>
    <td class="p-2 border-r border-slate-200 align-middle bg-slate-50/50">
      <div v-if="!isVisuel" class="text-[10px] text-slate-400 font-bold text-center italic select-none">
          Défini au plan article
      </div>
      <div v-else class="text-[12px] text-slate-300 font-black text-center select-none" title="Pas de valeur numérique pour un contrôle visuel">
          -
      </div>
    </td>

    <td class="p-2 border-r border-slate-200 align-top">
      <select v-model="ligne.typeControleId" :disabled="isReadOnly" :class="['w-full rounded px-2 py-1.5 text-[11px] outline-none focus:border-blue-500', isReadOnly ? 'bg-slate-100 border-slate-200 text-slate-500 cursor-not-allowed' : 'bg-white border border-slate-200 text-slate-700 cursor-pointer']">
        <option :value="null" disabled>-- Type de contrôle * --</option>
        <option v-for="tco in (store.typesControle || [])" :key="tco.id" :value="tco.id">{{ tco.libelle }}</option>
      </select>
    </td>

    <td class="p-2 border-r border-slate-200 align-top">
            <select v-model="ligne.moyenControleId" :disabled="isReadOnly" 
              :class="['w-full rounded px-2 py-1.5 text-[11px] outline-none transition-opacity', isReadOnly ? 'bg-slate-100 border-slate-200 text-slate-500 cursor-not-allowed' : 'cursor-pointer bg-white border border-slate-200 text-slate-700']">
        <option :value="null" disabled>-- Moyen de contrôle * --</option>
        <option v-for="mc in (store.moyensControle || [])" :key="mc.id" :value="mc.id">{{ mc.libelle }}</option>
      </select>
    </td>

    <td class="p-2 border-r border-slate-200 align-top">
      <div class="flex gap-1">
        <select 
          @change="(e) => { if (e.target.value) ligne.instrumentCode = e.target.value; e.target.value = ''; }"
          :disabled="isVisuel || isReadOnly"
          :class="(isVisuel || isReadOnly) ? 'opacity-50 cursor-not-allowed bg-slate-100' : 'cursor-pointer bg-white'"
          class="flex-1 border border-slate-200 rounded px-2 py-1.5 text-[11px] text-slate-700 outline-none focus:border-blue-500 transition-opacity">
          <option value="">-- Outil --</option>
          <option v-for="ins in (store.instruments || [])" :key="ins.codeInstrument" :value="ins.codeInstrument">
            {{ ins.codeInstrument }}
          </option>
        </select>
        <input 
          v-model="ligne.instrumentCode" 
          type="text" 
          placeholder="Perso"
          :disabled="isVisuel || isReadOnly"
          :class="(isVisuel || isReadOnly) ? 'opacity-50 cursor-not-allowed bg-slate-100' : 'bg-white'"
          class="flex-1 border border-slate-200 rounded px-2 py-1.5 text-[11px] text-slate-700 outline-none focus:border-blue-500 transition-opacity" />
      </div>
    </td>

    <td class="p-2 border-r border-slate-200 align-top">
            <input v-model="ligne.instruction" type="text" placeholder="Observations (Optionnel)..." :disabled="isReadOnly"
              :class="['w-full rounded px-2 py-1.5 text-xs outline-none focus:border-blue-500', isReadOnly ? 'bg-slate-100 border-slate-200 text-slate-500 cursor-not-allowed' : 'bg-white border border-slate-200 text-slate-600']">
    </td>

    <td class="p-2 align-middle text-center opacity-0 group-hover:opacity-100 transition-opacity">
      <button v-if="!isReadOnly" @click="$emit('remove', ligne.id)" class="text-slate-300 hover:text-red-500 transition-colors p-2 rounded-lg hover:bg-red-50" title="Supprimer cette ligne">
        <i class="pi pi-trash"></i>
      </button>
    </td>
  </tr>
</template>

<script setup>
import { ref, computed, watch } from 'vue';
import { useFabModeleStore } from '@/stores/fabModeleStore';
import { qualityPlansService } from '@/services/qualityPlansService';
import { useToast } from 'primevue/usetoast';

// Importation des composants PrimeVue manquants dans ce fichier
import Dropdown from 'primevue/dropdown';
import Dialog from 'primevue/dialog';
import InputText from 'primevue/inputtext';
import Checkbox from 'primevue/checkbox';
import Button from 'primevue/button';

const toast = useToast();

const props = defineProps({
  ligne: { type: Object, required: true },
  isReadOnly: { type: Boolean, default: false }
});

const isReadOnly = computed(() => props.isReadOnly);

defineEmits(['remove']);

const store = useFabModeleStore();

// =========================================================================
// LOGIQUE DE CRÉATION DE CARACTÉRISTIQUE À LA VOLÉE
// =========================================================================
const showAddCaractModal = ref(false);
const isSavingCaract = ref(false);

const newCaract = ref({
  libelle: '',
  estNumerique: true,
  uniteDefaut: ''
});

const creerCaracteristique = async () => {
  if (!newCaract.value.libelle) return;
  isSavingCaract.value = true;

  try {
    const payload = {
      libelle: newCaract.value.libelle.trim(),
      estNumerique: newCaract.value.estNumerique,
      uniteDefaut: newCaract.value.estNumerique ? newCaract.value.uniteDefaut.trim() : null
    };

    const response = await qualityPlansService.createCaracteristique(payload);
    const caractCree = response.data.data;
    
    // ⚠️ CORRECTION ICI : On utilise le bon nom de variable du store
    store.typesCaracteristique.push(caractCree); 

    // Sélectionne automatiquement la nouvelle caractéristique
    props.ligne.typeCaracteristiqueId = caractCree.id;

    toast.add({ severity: 'success', summary: 'Créée !', detail: 'La caractéristique a été ajoutée avec succès.', life: 3000 });
    
    // Reset et fermeture
    showAddCaractModal.value = false;
    newCaract.value = { libelle: '', estNumerique: true, uniteDefaut: '' };

  } catch (error) {
    toast.add({ severity: 'error', summary: 'Erreur', detail: error.response?.data?.message || 'Impossible de créer.', life: 5000 });
  } finally {
    isSavingCaract.value = false;
  }
};


// =========================================================================
// INTELLIGENCE : DÉTECTION ET NETTOYAGE DU MODE VISUEL
// =========================================================================

// 1. Détecte en temps réel si la ligne est un contrôle visuel UNIQUEMENT via le Type de Contrôle
const isVisuel = computed(() => {
  const typeCtrl = (store.typesControle || []).find(t => t.id === props.ligne.typeControleId);
  return (typeCtrl?.code === 'VISUEL');
});

// 2. Si on bascule sur Visuel, on nettoie automatiquement les instruments physiques uniquement
watch(isVisuel, (devenuVisuel) => {
  if (devenuVisuel) {
    // ⚠️ On a bien retiré la notion de groupeInstrumentId ici !
    props.ligne.instrumentCode = null;
  }
});
</script>